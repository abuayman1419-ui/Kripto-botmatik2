"""Gölge sinyal izleyici: işlem açılsın ya da açılmasın, üretilen sinyallerin sonradan ne olduğunu ölçer
(TP / SL / zaman aşımı, MFE / MAE). Puan eşiklerini ve stratejiyi kalibre etmek için veri toplar."""


class Shadow:
    def __init__(self, jlog):
        self.items, self.last, self.jlog, self.n = {}, {}, jlog, 0

    def add(self, kind, o, now, traded, target_r, horizon_min, ctx=None):
        side = o["side"]
        key = (o["symbol"], side, kind)
        if now - self.last.get(key, 0) < 1800 or len(self.items) >= 300:
            return
        self.last[key] = now
        r = abs(o["price"] - o["sl"])
        if r <= 0:
            return
        self.n += 1
        self.items[self.n] = {"kind": kind, "symbol": o["symbol"], "side": side, "d": 1 if side == "LONG" else -1,
                              "entry": o["price"], "sl": o["sl"], "r": r, "score": o["score"], "t0": now,
                              "target": target_r, "horizon": horizon_min * 60, "traded": bool(traded),
                              "mfe": 0.0, "mae": 0.0, "ctx": ctx or {}}

    def update(self, prices, now):
        for k, it in list(self.items.items()):
            px = prices.get(it["symbol"])
            if px is None:
                continue
            fav = (px - it["entry"]) * it["d"] / it["r"]
            it["mfe"], it["mae"] = max(it["mfe"], fav), max(it["mae"], -fav)
            out = "SL" if fav <= -1 else "TP" if fav >= it["target"] else "TIMEOUT" if now - it["t0"] > it["horizon"] else None
            if out:
                self.jlog("shadow_outcomes", {"kind": it["kind"], "symbol": it["symbol"], "side": it["side"],
                                              "score": it["score"], "traded": it["traded"], "outcome": out,
                                              "final_r": round(fav, 2), "mfe_r": round(it["mfe"], 2),
                                              "mae_r": round(it["mae"], 2), "min": int((now - it["t0"]) / 60),
                                              "target_r": it["target"], "ctx": it["ctx"]})
                del self.items[k]
