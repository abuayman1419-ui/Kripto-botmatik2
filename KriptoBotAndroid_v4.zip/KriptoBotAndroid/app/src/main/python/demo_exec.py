"""Binance DEMO hesabı emir yürütücüsü. YALNIZCA demo/testnet adreslerine bağlanır; canlı (fapi.binance.com) adresi kodda YOKTUR.
Anahtarlar yalnızca bellekte tutulur, diske yazılmaz, loglanmaz."""
import hashlib
import logging
import hmac
import time
import urllib.parse
from collections import deque
from decimal import ROUND_DOWN, ROUND_HALF_UP, Decimal

BASES = {"demo": "https://demo-fapi.binance.com", "testnet": "https://testnet.binancefuture.com"}


class Demo:
    def __init__(self):
        self.key = self.secret = None
        self.env = "demo"
        self.connected = False
        self.balance = None
        self.avail = None
        self.hedge = False
        self.offset = 0
        self.err = ""
        self.log = deque(maxlen=60)
        self.lev_set = set()
        self.s = None
        self.pos_snapshot = {}
        self.last_sync = 0.0
        self.stops = {}
        self.sync_fail = 0

    def synced(self):
        return self.connected and time.time() - self.last_sync <= 20

    def forget(self):
        self.pos_snapshot, self.stops, self.last_sync = {}, {}, 0.0
        self.key = self.secret = None
        self.connected, self.balance, self.avail, self.err = False, None, None, ""
        self.lev_set.clear()

    async def _req(self, method, path, signed=True, **params):
        import aiohttp
        if self.s is None:
            self.s = aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=15))
        base = BASES[self.env]
        headers = {}
        if signed:
            params["timestamp"] = int(time.time() * 1000) + self.offset
            params["recvWindow"] = 10000
            q = urllib.parse.urlencode(params)
            sig = hmac.new(self.secret.encode(), q.encode(), hashlib.sha256).hexdigest()
            q += "&signature=" + sig
            headers["X-MBX-APIKEY"] = self.key
        else:
            q = urllib.parse.urlencode(params)
        async with self.s.request(method, f"{base}{path}?{q}", headers=headers) as r:
            txt = await r.text()
            if r.status >= 400:
                raise RuntimeError(f"HTTP {r.status}: {txt[:160]}")
            import json
            return json.loads(txt)

    async def connect(self, key, secret, env):
        if env not in BASES:
            raise ValueError("Geçersiz ortam")
        self.key, self.secret, self.env = key.strip(), secret.strip(), env
        self.connected = False
        t = await self._req("GET", "/fapi/v1/time", signed=False)
        self.offset = int(t["serverTime"]) - int(time.time() * 1000)
        try:
            acc = await self._req("GET", "/fapi/v3/account")
        except Exception:
            acc = await self._req("GET", "/fapi/v2/account")
        self.balance = float(acc.get("totalWalletBalance", 0))
        self.avail = float(acc.get("availableBalance", 0))
        try:
            self.hedge = bool((await self._req("GET", "/fapi/v1/positionSide/dual")).get("dualSidePosition"))
        except Exception:
            self.hedge = False
        self.connected, self.err = True, ""
        self.note(f"Bağlandı ({env}), bakiye {self.balance:.2f} USDT" + (", hedge modu" if self.hedge else ""))

    def note(self, msg):
        self.log.appendleft({"t": time.strftime("%H:%M:%S"), "m": msg})
        logging.getLogger("bot.demo").info(msg)

    @staticmethod
    def fit(qty, flt):
        step = Decimal(str(flt.get("step") or 0))
        q = Decimal(str(qty))
        if step > 0:
            q = (q / step).to_integral_value(rounding=ROUND_DOWN) * step
        return q

    async def place(self, sym, side, qty, reduce, flt, lev, price):
        q = self.fit(qty, flt)
        if q <= 0 or float(q) < flt.get("minq", 0) or (not reduce and float(q) * price < flt.get("notional", 5)):
            raise RuntimeError(f"{sym}: miktar borsa limitlerinin altında ({q})")
        if not reduce and sym not in self.lev_set:
            try:
                await self._req("POST", "/fapi/v1/marginType", symbol=sym, marginType="CROSSED")
            except Exception:
                pass            # zaten CROSSED ise hata döner, önemsiz
            await self._req("POST", "/fapi/v1/leverage", symbol=sym, leverage=int(lev))
            self.lev_set.add(sym)
        long = side == "LONG"
        order_side = ("BUY" if long else "SELL") if not reduce else ("SELL" if long else "BUY")
        p = {"symbol": sym, "side": order_side, "type": "MARKET", "quantity": format(q, "f"), "newOrderRespType": "RESULT"}
        if self.hedge:
            p["positionSide"] = "LONG" if long else "SHORT"
        elif reduce:
            p["reduceOnly"] = "true"
        r = await self._req("POST", "/fapi/v1/order", **p)
        self.note(f"{'KAPAT' if reduce else 'AÇ'} {sym} {side} {p['quantity']} @ {r.get('avgPrice', '?')}")
        return r

    # ---------- borsa senkronu ----------
    async def positions(self):
        try:
            arr = await self._req("GET", "/fapi/v3/positionRisk")
        except Exception:
            arr = await self._req("GET", "/fapi/v2/positionRisk")
        out = {}
        for x in arr:
            amt = float(x.get("positionAmt", 0) or 0)
            if amt:
                out[x["symbol"]] = {"qty": abs(amt), "side": "LONG" if amt > 0 else "SHORT", "entry": float(x["entryPrice"]),
                                    "mark": float(x["markPrice"]), "upnl": float(x.get("unRealizedProfit", 0) or 0)}
        return out

    @staticmethod
    def fmt_price(price, tick):
        q, t = Decimal(str(price)), Decimal(str(tick or 0))
        if t > 0:
            q = (q / t).to_integral_value(rounding=ROUND_HALF_UP) * t
        return format(q, "f")

    async def set_stop(self, sym, side, price, tick):
        """Borsada closePosition STOP_MARKET (Algo Order) koyar/günceller. Önce yenisi konur, sonra eskisi iptal edilir."""
        long = side == "LONG"
        p = {"algoType": "CONDITIONAL", "symbol": sym, "side": "SELL" if long else "BUY", "type": "STOP_MARKET",
             "triggerPrice": self.fmt_price(price, tick), "closePosition": "true", "workingType": "MARK_PRICE",
             "priceProtect": "false"}
        if self.hedge:
            p["positionSide"] = "LONG" if long else "SHORT"
        try:
            r = await self._req("POST", "/fapi/v1/algoOrder", **p)
        except RuntimeError as e:
            if "-2021" in str(e) or "immediately trigger" in str(e).lower():
                return "TRIGGERED"
            raise
        old = self.stops.get(sym)
        self.stops[sym] = {"id": r.get("algoId"), "price": float(price), "ts": time.time(), "chk": time.time()}
        if old and old.get("id") and old["id"] != r.get("algoId"):
            try:
                await self._req("DELETE", "/fapi/v1/algoOrder", algoId=old["id"])
            except Exception:
                pass
        self.note(f"BORSA SL {sym} {side} @ {p['triggerPrice']}")
        return "OK"

    async def cancel_stops(self, sym):
        self.stops.pop(sym, None)
        await self._req("DELETE", "/fapi/v1/algoOpenOrders", symbol=sym)

    async def check_stop(self, sym):
        """Borsada bu sembol için STOP_MARKET var mı? Yoksa kayıttan düşür (yeniden konsun)."""
        arr = await self._req("GET", "/fapi/v1/openAlgoOrders", symbol=sym)
        ok = [o for o in arr if o.get("orderType") == "STOP_MARKET" and o.get("closePosition")]
        if ok:
            o = ok[0]
            self.stops[sym] = {"id": o.get("algoId"), "price": float(o.get("triggerPrice", 0)), "ts": self.stops.get(sym, {}).get("ts", time.time()), "chk": time.time()}
        else:
            self.stops.pop(sym, None)

    # ---------- isteğe bağlı yerel anahtar saklama (demo anahtarı) ----------
    def save_creds(self, path):
        import json
        import os
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as fh:
            json.dump({"key": self.key, "secret": self.secret, "env": self.env}, fh)
        try:
            os.chmod(path, 0o600)
        except Exception:
            pass

    @staticmethod
    def load_creds(path):
        import json
        try:
            with open(path, encoding="utf-8") as fh:
                return json.load(fh)
        except Exception:
            return None

    @staticmethod
    def delete_creds(path):
        import os
        try:
            os.remove(path)
        except Exception:
            pass

    async def refresh_balance(self):
        try:
            acc = await self._req("GET", "/fapi/v2/account")
            self.balance, self.avail = float(acc["totalWalletBalance"]), float(acc["availableBalance"])
        except Exception as e:
            self.err = str(e)[:120]
