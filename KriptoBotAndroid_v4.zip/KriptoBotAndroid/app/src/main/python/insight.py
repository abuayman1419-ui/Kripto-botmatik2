"""Fırsat kartları için Türkçe açıklama: para akışı detayı, Bollinger sıkışma senaryosu, seviyeler.
Buradaki hedefler TAHMİN DEĞİL; ATR ve destek/direnç tabanlı senaryo hesaplarıdır."""
import math
from indicators import atr, bollinger, last


def _pivots(d, price, n=48):
    h, l = d.h.to_numpy()[-n:], d.l.to_numpy()[-n:]
    ph = [h[i] for i in range(2, len(h) - 2) if h[i] == max(h[i - 2:i + 3])]
    pl = [l[i] for i in range(2, len(l) - 2) if l[i] == min(l[i - 2:i + 3])]
    up = [x for x in ph if x > price]
    dn = [x for x in pl if x < price]
    res = min(up) if up else float(h.max())
    sup = max(dn) if dn else float(l.min())
    return float(res), float(sup)


def pct(a, b):
    return (a - b) / b * 100


def build(o, f, cfg):
    d5, d15 = f["5m"], f["15m"]
    px, a5 = o["price"], o["atr"]
    res, sup = _pivots(d15, px)
    exp = last(atr(d15)) / px * 100 * 2          # ~1 saatlik olağan oynaklık
    R = cfg.sl_atr_mult * a5
    b = o["biases"]
    flow = b["flow"]
    kind = "GİRİŞ" if flow > 0.4 else "ÇIKIŞ" if flow < -0.4 else "KARIŞIK"

    drivers = []
    tb = o["taker_buy"]
    drivers.append({"s": 1 if tb > 0.55 else -1 if tb < 0.45 else 0,
                    "t": f"Taker alış oranı %{tb * 100:.0f}: {'alıcılar baskın' if tb > 0.55 else 'satıcılar baskın' if tb < 0.45 else 'dengeli'}"})
    drivers.append({"s": (1 if o["vol_ratio"] > 1.5 and tb >= 0.5 else -1 if o["vol_ratio"] > 1.5 else 0),
                    "t": f"Hacim normalin {o['vol_ratio']:.1f} katı" + (" (ani ilgi)" if o["vol_ratio"] > 2 else "")})
    if o["oi_change_pct"] is not None:
        oi = o["oi_change_pct"]
        drivers.append({"s": 1 if b["oi_funding"] > 0.3 else -1 if b["oi_funding"] < -0.3 else 0,
                        "t": f"Open Interest son 30 dk %{oi:+.1f}: " + ("yeni pozisyon girişi" if oi > 0.5 else "pozisyon kapanışı" if oi < -0.5 else "belirgin değişim yok")})
    if o["funding"] is not None:
        fu = o["funding"] * 100
        drivers.append({"s": -1 if abs(fu) > 0.05 else 0,
                        "t": f"Funding %{fu:.3f}" + (": long'lar kalabalık, geri çekilme riski" if fu > 0.05 else ": short'lar kalabalık, sıkışma (squeeze) riski" if fu < -0.05 else ": normal")})
    ob = b["orderbook"]
    drivers.append({"s": 1 if ob > 0.25 else -1 if ob < -0.25 else 0,
                    "t": "Emir defteri: " + ("alış tarafı güçlü" if ob > 0.25 else "satış tarafı güçlü" if ob < -0.25 else "dengeli")})
    if abs(b["btc"]) > 0.25:
        drivers.append({"s": 1 if b["btc"] > 0 else -1, "t": f"BTC eğilimi {'olumlu' if b['btc'] > 0 else 'olumsuz'}"})
    if abs(b["news"]) > 0.05:
        drivers.append({"s": 1 if b["news"] > 0 else -1, "t": "Son haberler " + ("olumlu" if b["news"] > 0 else "olumsuz")})
    if o["patterns"]:
        drivers.append({"s": 0, "t": "Formasyon: " + ", ".join(p for p in o["patterns"] if p != "Doji")})

    up_pct, dn_pct = pct(res, px), pct(px, sup)
    tgt_up, tgt_dn = px + 3 * R, px - 3 * R
    if kind == "GİRİŞ":
        eff = (f"Kısa vadede (15–60 dk) yukarı yönlü baskı var. Direnç {res:.6g} (+%{up_pct:.2f}) üstünde 5m kapanış ve retest gelirse "
               f"hareket {tgt_up:.6g} (+%{pct(tgt_up, px):.2f}) bölgesine uzayabilir. Onay gelmezse geri çekilme riski: destek {sup:.6g} (-%{dn_pct:.2f}).")
        pot = pct(tgt_up, px)
    elif kind == "ÇIKIŞ":
        eff = (f"Kısa vadede (15–60 dk) aşağı yönlü baskı var. Destek {sup:.6g} (-%{dn_pct:.2f}) altında 5m kapanış gelirse "
               f"düşüş {tgt_dn:.6g} (-%{pct(px, tgt_dn):.2f}) bölgesine uzayabilir. Toparlanma olursa direnç {res:.6g} (+%{up_pct:.2f}) izlenmeli.")
        pot = -pct(px, tgt_dn)
    else:
        eff = f"Yön net değil. Destek {sup:.6g} ile direnç {res:.6g} arası sıkışık; kırılım yönü beklenmeli."
        pot = 0.0
    fd = {"kind": kind, "drivers": drivers, "effect": eff, "pot_pct": round(pot, 2),
          "res": res, "sup": sup, "exp_move_pct": round(exp, 2),
          "disclaimer": "Hedefler ATR ve seviye tabanlı senaryodur, tahmin/garanti değildir."}

    bu, bm, bl = bollinger(d5.c)
    bu, bm, bl = last(bu), last(bm), last(bl)
    bw = (bu - bl) / bm if bm else 0
    bws = ((d5.c.rolling(20).std() * 4) / d5.c.rolling(20).mean()).iloc[-50:]
    ratio = bw / float(bws.median()) if float(bws.median()) else 1
    diff = o["long"] - o["short"]
    lean = ("alıcı tarafı hafif önde (yukarı kırılım ihtimali biraz daha yüksek görünüyor, garanti değil)" if diff > 8 else
            "satıcı tarafı hafif önde (aşağı kırılım ihtimali biraz daha yüksek görünüyor, garanti değil)" if diff < -8 else
            "taraflar dengeli, yön henüz belli değil")
    L = [bu + R * k for k in (1, 2, 3)]
    S = [bl - R * k for k in (1, 2, 3)]
    sq = {"bb_up": bu, "bb_mid": bm, "bb_lo": bl, "ratio": round(ratio, 2), "squeeze": o["squeeze"], "lean": lean,
          "long": {"trigger": bu, "tps": L, "invalid": bm, "pot_pct": round(pct(L[2], bu), 2)},
          "short": {"trigger": bl, "tps": S, "invalid": bm, "pot_pct": round(pct(bl, S[2]), 2)}}
    sq["summary"] = (
        f"{o['symbol']}: 5m Bollinger bant genişliği son 50 mumun medyanının %{ratio * 100:.0f}'i seviyesinde"
        f"{' (belirgin sıkışma)' if o['squeeze'] else ''}. Hacim normalin {o['vol_ratio']:.1f} katı; {lean}. "
        f"YUKARI senaryo: 5m kapanış {bu:.6g} üstüne çıkar ve hacim artarsa hedefler {L[0]:.6g} / {L[2]:.6g} (+%{pct(L[2], bu):.2f}); "
        f"{bm:.6g} altına dönüş senaryoyu geçersiz kılar. "
        f"AŞAĞI senaryo: 5m kapanış {bl:.6g} altına iner ve hacim artarsa hedefler {S[0]:.6g} / {S[2]:.6g} (-%{pct(bl, S[2]):.2f}); "
        f"{bm:.6g} üstüne dönüş geçersiz kılar. Sahte kırılıma karşı kapanış + retest beklenmeli.")
    return {"res": res, "sup": sup, "fd": fd, "sq": sq, "spark": [round(float(x), 8) for x in d5.c.iloc[-36:]]}
