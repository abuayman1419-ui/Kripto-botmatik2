"""Log özeti ve dışa aktarma: logs klasöründen analiz için tek bir zip + summary.md üretir."""
import collections
import io
import json
import os
import re
import zipfile

FILES = ["bot.log", "paper_trades.jsonl", "trade_events.jsonl", "signals.jsonl", "decisions.jsonl",
         "shadow_outcomes.jsonl", "scan_stats.jsonl", "alarms.jsonl", "config_changes.jsonl", "universe.jsonl", "settings.json"]


def _read(d, name):
    p = os.path.join(d, name)
    out = []
    if os.path.exists(p):
        with open(p, encoding="utf-8", errors="replace") as fh:
            for ln in fh:
                try:
                    out.append(json.loads(ln))
                except Exception:
                    pass
    return out


def _bucket(x):
    return "90+" if x >= 90 else f"{int(x // 10) * 10}-{int(x // 10) * 10 + 9}"


def _agg(rows, key):
    g = collections.defaultdict(list)
    for r in rows:
        g[key(r)].append(r)
    return g


def summarize(d="logs"):
    L = ["# CRYPTO AI TERMINAL — log özeti", ""]
    tr = [r for r in _read(d, "paper_trades.jsonl") if r.get("final")]
    L.append(f"## İşlemler (tamamen kapanan): {len(tr)}")
    if tr:
        tot = [r.get("trade_total", r["pnl"]) or 0 for r in tr]
        L.append(f"- Net: {sum(tot):.2f} USDT · kazanç oranı %{100 * sum(1 for x in tot if x > 0) / len(tot):.0f} · ort. süre {sum(r['duration_s'] for r in tr) / len(tr) / 60:.0f} dk")
        for title, key in (("Yöne göre", lambda r: r["side"]), ("Stratejiye göre", lambda r: r.get("strat", "STD")),
                           ("Puan aralığına göre", lambda r: _bucket(r["score"]))):
            L.append(f"- {title}:")
            for k, v in sorted(_agg(tr, key).items()):
                t = [x.get("trade_total", x["pnl"]) or 0 for x in v]
                L.append(f"  - {k}: {len(v)} işlem, net {sum(t):.2f}, kazanç %{100 * sum(1 for x in t if x > 0) / len(t):.0f}")
        L.append("- Çıkış nedenine göre (parça bazlı):")
        for k, v in sorted(_agg(_read(d, "paper_trades.jsonl"), lambda r: r["reason"]).items(), key=lambda kv: -len(kv[1])):
            L.append(f"  - {k}: {len(v)} adet, toplam {sum(x['pnl'] for x in v):.2f}")
        mf = [r["mfe_r"] for r in tr if r.get("mfe_r") is not None]
        ma = [r["mae_r"] for r in tr if r.get("mae_r") is not None]
        if mf:
            L.append(f"- Ortalama MFE {sum(mf) / len(mf):.2f}R / MAE {sum(ma) / len(ma):.2f}R (MFE yüksek ama sonuç düşükse çıkış erken/geç olabilir)")
    sh = _read(d, "shadow_outcomes.jsonl")
    L += ["", f"## Gölge sinyaller (işlem açılmasa da izlenen): {len(sh)}"]
    for (kind, side), v in sorted(_agg(sh, lambda r: (r["kind"], r["side"])).items()):
        c = collections.Counter(x["outcome"] for x in v)
        L.append(f"- {kind}/{side}: {len(v)} sinyal · TP %{100 * c['TP'] / len(v):.0f} · SL %{100 * c['SL'] / len(v):.0f} · zaman aşımı %{100 * c['TIMEOUT'] / len(v):.0f} · ort. MFE {sum(x['mfe_r'] for x in v) / len(v):.2f}R / MAE {sum(x['mae_r'] for x in v) / len(v):.2f}R")
    for kind, v in sorted(_agg(sh, lambda r: r["kind"]).items()):
        for b, w in sorted(_agg(v, lambda r: _bucket(r["score"])).items()):
            c = collections.Counter(x["outcome"] for x in w)
            L.append(f"  - {kind} puan {b}: {len(w)} sinyal, TP %{100 * c['TP'] / len(w):.0f}, SL %{100 * c['SL'] / len(w):.0f}")
    dec = _read(d, "decisions.jsonl")
    L += ["", f"## Reddedilen/engellenen girişler: {len(dec)}"]
    for k, n in collections.Counter(r["reason"] for r in dec).most_common(12):
        L.append(f"- {k}: {n}")
    sc = _read(d, "scan_stats.jsonl")
    L += ["", f"## Taramalar: {len(sc)}"]
    if sc:
        L.append(f"- Ort. tarama süresi {sum(r['ms'] for r in sc) / len(sc):.0f} ms · en uzun {max(r['ms'] for r in sc)} ms")
        L.append(f"- Ort. taranan taze sembol {sum(r['fresh'] for r in sc) / len(sc):.0f}/{sc[-1].get('perp_total')} · likit {sc[-1].get('liquid')} · derin analiz ort. {sum(r['deep'] for r in sc) / len(sc):.0f}")
        sig = {s: sum(r["sides"][s]["sig"] for r in sc) for s in ("LONG", "SHORT")}
        nn = {s: sum(r["sides"][s]["n"] for r in sc) for s in ("LONG", "SHORT")}
        L.append(f"- Toplam aday/sinyal — LONG {nn['LONG']}/{sig['LONG']} · SHORT {nn['SHORT']}/{sig['SHORT']}")
        bl = collections.Counter()
        for r in sc:
            for s in ("LONG", "SHORT"):
                for k, n in r["sides"][s]["blocked"].items():
                    bl[f"{s}: {k}"] += n
        L.append("- En sık engelleyen filtreler: " + "; ".join(f"{k} ×{n}" for k, n in bl.most_common(8)))
        L.append(f"- Rejimler: " + ", ".join(f"{k} {n}" for k, n in collections.Counter(r.get("regime") for r in sc).most_common()))
        L.append(f"- REST ile yenilenen sembol (WS gecikmesi) ortalaması {sum(r.get('rest_fallback', 0) for r in sc) / len(sc):.0f}; WS eksik tarama sayısı {sum(1 for r in sc if r.get('ws_missing'))}")
    lg = os.path.join(d, "bot.log")
    L += ["", "## Hatalar / uyarılar (bot.log)"]
    if os.path.exists(lg):
        c = collections.Counter()
        with open(lg, encoding="utf-8", errors="replace") as fh:
            for ln in fh:
                m = re.match(r"\S+ \S+ (ERROR|WARNING) (\S+) (.*)", ln)
                if m:
                    c[f"{m.group(1)} {m.group(2)} {re.sub(r'[0-9.]+', '#', m.group(3))[:110]}"] += 1
        for k, n in c.most_common(15):
            L.append(f"- ×{n} {k}")
        if not c:
            L.append("- Hata/uyarı kaydı yok")
    al = _read(d, "alarms.jsonl")
    L += ["", f"## Haber alarmları: {len(al)}"] + [f"- {r['t']} [{r['level']}] {r['title'][:100]}" for r in al[-8:]]
    notes = []
    if sc and nn["SHORT"] and not sig["SHORT"] and sig["LONG"] > 5:
        notes.append("Short adayları var ama hiç Short sinyali yok: BTC koruması/puan eşiği gözden geçirilmeli.")
    if sc and sum(1 for r in sc if r.get("ws_missing")) > len(sc) * 0.2:
        notes.append("Taramaların %20'sinden fazlasında WebSocket eksik: ağ/WS sorunu olabilir.")
    if tr and len(tr) >= 20:
        notes.append("İşlem sayısı yeterli: puan aralığına göre kazanç oranlarını karşılaştırın.")
    L += ["", "## Otomatik uyarılar"] + ([f"- {n}" for n in notes] or ["- (şimdilik yok)"])
    return "\n".join(L)


def export_zip(d="logs", tail_bytes=8_000_000):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("summary.md", summarize(d))
        z.writestr("README.txt", "Bu paket CRYPTO AI TERMINAL logları içerir. summary.md özettir; *.jsonl dosyaları satır başına bir JSON olaydır "
                   "(trade_events: açılış/stop taşıma/kapanış, signals: sinyaller, decisions: reddedilen girişler, shadow_outcomes: sinyal sonuçları, "
                   "scan_stats: tarama metrikleri, alarms: haber alarmları). API anahtarı/secret içermez.")
        for n in FILES:
            p = os.path.join(d, n)
            if os.path.exists(p):
                sz = os.path.getsize(p)
                with open(p, "rb") as fh:
                    if sz > tail_bytes:
                        fh.seek(-tail_bytes, 2)
                        fh.readline()
                    z.writestr(n, fh.read())
    return buf.getvalue()
