"""PAPER işlem motoru + risk yöneticisi. Gerçek emir göndermez; hiçbir borsa çağrısı içermez.
İki strateji: STD (sabit SL + TP1/2/3) ve REV (dip/tepe dönüşü, trailing stop)."""
import json
import os
from collections import deque
from datetime import datetime, timezone

MANUAL = {"Elle kapatıldı", "Borsada elle kapatıldı"}


class PaperEngine:
    def __init__(self, cfg):
        self.cfg = cfg
        self.start = cfg.start_balance          # performans baz çizgisi (panelden/demo'dan senkronlanır)
        self.balance = cfg.start_balance
        self.pos = {}
        self.closed = []
        self.consec_losses = 0
        self.cooldown_until = 0.0
        self.peak = cfg.start_balance
        self.max_dd = 0.0
        self.day = self._today()
        self.day_start = cfg.start_balance
        self.halted = None
        self.safe_mode = False
        self.paused = False
        self.demo_on = False
        self.queue = []
        self.eq_hist = deque(maxlen=720)
        self.on_event = None
        self.block_until = {}
        self.closing = {}
        self.gate = None
        os.makedirs(cfg.log_dir, exist_ok=True)
        self.log_path = os.path.join(cfg.log_dir, "paper_trades.jsonl")

    @staticmethod
    def _today():
        return datetime.now(timezone.utc).strftime("%Y-%m-%d")

    def emit(self, name, d):
        if self.on_event:
            try:
                self.on_event(name, d)
            except Exception:
                pass

    @staticmethod
    def is_free(p):
        """Stop girişin (veya kârın) ötesine çekildiyse pozisyon risksizdir."""
        return (p["sl"] - p["entry"]) * p["dir"] >= 0

    def active_count(self):
        return sum(1 for p in self.pos.values() if not self.is_free(p))

    def used_margin(self):
        return sum(p["qty_open"] * p["entry"] / p["leverage"] for p in self.pos.values())

    # ---------- değerleme ----------
    def unrealized(self, prices):
        return sum((prices.get(s, p["entry"]) - p["entry"]) * p["qty_open"] * p["dir"] for s, p in self.pos.items())

    def equity(self, prices):
        return self.balance + self.unrealized(prices)

    def set_start(self, v):
        """Başlangıç bakiyesini değiştirir (açık pozisyon yokken). Net K/Z tutarlı kalır."""
        if self.pos:
            return False
        d = v - self.start
        self.start += d
        self.balance += d
        self.peak += d
        self.day_start += d
        return True

    # ---------- risk kapıları ----------
    def can_open(self, symbol, now):
        c = self.cfg
        if self.day != self._today():
            self.day, self.day_start, self.halted = self._today(), self.balance, None
        if self.paused:
            return False, "Alım-satım elle durduruldu"
        if self.gate:
            g = self.gate()
            if g:
                return False, g
        if now < self.block_until.get(symbol, 0):
            return False, "Bu coin için bekleme süresi (kapatma/stop sonrası)"
        if self.safe_mode:
            return False, "Veri akışı güvenli modda"
        if self.halted:
            return False, self.halted
        if symbol in self.pos:
            return False, "Aynı coinde açık pozisyon var"
        if len(self.pos) >= c.max_total_positions:
            return False, "Toplam pozisyon üst sınırı"
        if self.active_count() >= c.max_positions:
            return False, "Maksimum aktif (riskli) pozisyon"
        if now < self.cooldown_until:
            return False, "Üst üste zarar sonrası bekleme"
        if self.balance - self.day_start <= -c.daily_loss_pct * self.day_start:
            self.halted = "Günlük zarar limiti doldu"
            return False, self.halted
        return True, ""

    # ---------- işlem açma ----------
    def open(self, opp, price, now):
        c = self.cfg
        ok, why = self.can_open(opp["symbol"], now)
        if not ok:
            return False, why
        if abs(price - opp["price"]) > c.max_slippage_atr * opp["atr"]:
            return False, "Fiyat sinyalden fazla kaçtı"
        strat = opp.get("strat", "STD")
        d = 1 if opp["side"] == "LONG" else -1
        r = abs(opp["price"] - opp["sl"])
        sl = price - d * r
        if strat == "REV":
            tps = [price + d * c.rev_partial_r * r] if c.rev_partial_r > 0 else []
        else:
            tps = [price + d * k * r for k in c.tp_r]
        qty = (self.balance * c.risk_pct) / r
        avail = max(self.balance - self.used_margin(), 0)
        qty = min(qty, self.balance * c.margin_pct * c.leverage / price, avail * c.leverage * 0.98 / price)
        if qty * price < 5:
            return False, "Pozisyon çok küçük"
        fee = qty * price * c.taker_fee
        self.balance -= fee
        self.pos[opp["symbol"]] = {
            "symbol": opp["symbol"], "side": opp["side"], "dir": d, "entry": price, "qty": qty,
            "qty_open": qty, "sl": sl, "sl0": sl, "tps": tps, "tp_hit": 0, "leverage": c.leverage,
            "margin": qty * price / c.leverage, "opened": now, "fees": fee, "realized": 0.0,
            "score": opp["score"], "reason": opp["note"], "hist": deque(maxlen=40),
            "strat": strat, "r": r, "best": price, "atr": opp["atr"], "be_done": False,
            "partial_done": False, "trail_n": 0, "worst": price, "sl_logged": sl, "free_logged": False,
            "exch": self.demo_on, "exch_ok": not self.demo_on}
        self.emit("open", {"symbol": opp["symbol"], "side": opp["side"], "strat": strat, "entry": price, "qty": qty,
                          "sl": sl, "r": r, "atr": opp["atr"], "score": opp["score"], "note": opp["note"],
                          "balance": round(self.balance, 2), "active": self.active_count(), "total": len(self.pos),
                          "ctx": opp.get("ctx") or {}})
        if self.demo_on:
            self.queue.append({"kind": "open", "sym": opp["symbol"], "side": opp["side"], "qty": qty, "reduce": False})
        return True, ""

    # ---------- fiyat takibi ----------
    def _trail(self, p, px):
        c, d, e = self.cfg, p["dir"], p["entry"]
        if (px - p["best"]) * d > 0:
            p["best"] = px
        prof = (p["best"] - e) * d / p["r"]
        if not p["be_done"] and prof >= c.rev_be_r:
            be = e * (1 + d * 0.001)
            p["sl"] = max(p["sl"], be) if d > 0 else min(p["sl"], be)
            p["be_done"] = True
        if p["be_done"]:
            k = c.rev_trail_atr * (0.6 if prof >= 6 else 0.8 if prof >= 3 else 1.0)
            cand = p["best"] - d * k * p["atr"]
            if (cand - p["sl"]) * d > 0:
                p["sl"] = cand
                p["trail_n"] += 1
                if abs(cand - p["sl_logged"]) >= 0.25 * p["r"]:
                    p["sl_logged"] = cand
                    self.emit("sl_move", {"symbol": p["symbol"], "sl": cand, "best": p["best"], "r_now": round(prof, 2), "n": p["trail_n"]})

    def mark(self, prices, now):
        c = self.cfg
        for s in list(self.pos):
            p = self.pos[s]
            px = prices.get(s)
            if px is None:
                continue
            if p.get("exch") and not self.demo_on:
                continue                     # borsa bağlı değil: borsadaki SL korur, burada kapatma yok
            d = p["dir"]
            p["hist"].append((now, px))
            if (px - p["best"]) * d > 0:
                p["best"] = px
            if (p["worst"] - px) * d > 0:
                p["worst"] = px
            old = next((x for t, x in p["hist"] if now - t <= 60), None)
            if old and (px - old) / old * 100 * d <= -c.panic_move_pct:
                self._close(p, p["qty_open"], px, "Ani volatilite koruması", now)
                continue
            rev = p["strat"] in ("REV", "ADOPT")
            if rev:
                self._trail(p, px)
            if (px - p["sl"]) * d <= 0:
                reason = (("Trailing Stop" if p["be_done"] else "Stop Loss") if rev
                          else ("Stop Loss" if p["tp_hit"] == 0 else "Stop (kâr korumalı)"))
                self._close(p, p["qty_open"], px, reason, now)
                continue
            if self.is_free(p) and not p["free_logged"]:
                p["free_logged"] = True
                self.emit("risk_free", {"symbol": s, "side": p["side"], "sl": p["sl"], "entry": p["entry"], "px": px,
                                      "strat": p["strat"], "active": self.active_count(), "total": len(self.pos)})
            if rev:
                if p["tps"] and not p["partial_done"] and (px - p["tps"][0]) * d >= 0:
                    p["partial_done"] = True
                    self._close(p, min(p["qty_open"], p["qty"] * c.rev_partial_pct), p["tps"][0], "Kısmi kâr (dönüş)", now)
                if s in self.pos and now - p["opened"] > c.rev_max_hold_hours * 3600:
                    self._close(p, p["qty_open"], px, "Zaman aşımı", now)
                continue
            while p["tp_hit"] < len(p["tps"]) and (px - p["tps"][p["tp_hit"]]) * d >= 0:
                i = p["tp_hit"]
                last_tp = i == len(p["tps"]) - 1
                q = p["qty_open"] if last_tp else min(p["qty_open"], p["qty"] * c.tp_split[i])
                p["tp_hit"] += 1
                if i == 0:
                    p["sl"] = p["entry"]
                elif i == 1:
                    p["sl"] = p["tps"][0]
                self._close(p, q, p["tps"][i], f"TP{i + 1}", now)
                if s not in self.pos:
                    break
            if s in self.pos and now - p["opened"] > c.max_hold_minutes * 60:
                self._close(p, p["qty_open"], px, "Zaman aşımı", now)

    def _close(self, p, qty, price, reason, now, send=True):
        c = self.cfg
        pnl = (price - p["entry"]) * qty * p["dir"]
        fee = price * qty * c.taker_fee
        self.balance += pnl - fee
        p["realized"] += pnl - fee
        p["fees"] += fee
        p["qty_open"] -= qty
        full = p["qty_open"] <= 1e-12
        sendq = self.demo_on and send and p.get("exch")
        if sendq:
            self.queue.append({"kind": "close", "sym": p["symbol"], "side": p["side"], "qty": qty, "reduce": True, "final": full})
        rec = {"time": datetime.fromtimestamp(now, timezone.utc).isoformat(timespec="seconds"),
               "symbol": p["symbol"], "side": p["side"], "entry": p["entry"], "exit": price,
               "qty": qty, "pnl": round(pnl - fee, 4), "reason": reason, "strat": p["strat"],
               "final": full, "duration_s": int(now - p["opened"]), "leverage": p["leverage"],
               "score": p["score"], "open_reason": p["reason"],
               "trade_total": round(p["realized"], 4) if full else None,
               "mfe_r": round((p["best"] - p["entry"]) * p["dir"] / p["r"], 2) if full else None,
               "mae_r": round((p["entry"] - p["worst"]) * p["dir"] / p["r"], 2) if full else None}
        self.emit("close", rec)
        self.closed.append(rec)
        with open(self.log_path, "a", encoding="utf-8") as fh:
            fh.write(json.dumps(rec, ensure_ascii=False) + "\n")
        self.peak = max(self.peak, self.balance)
        self.max_dd = max(self.max_dd, (self.peak - self.balance) / self.peak)
        if full:
            mins = c.manual_close_block_min if reason in MANUAL else c.reentry_block_min
            self.block_until[p["symbol"]] = now + mins * 60
            if sendq:
                self.closing[p["symbol"]] = now
            self.consec_losses = self.consec_losses + 1 if p["realized"] < 0 else 0
            if self.consec_losses >= c.max_consec_losses:
                self.cooldown_until = now + c.cooldown_minutes * 60
                self.consec_losses = 0
            del self.pos[p["symbol"]]

    # ---------- elle kontrol ----------
    def close_all(self, prices, now, reason="Elle kapatıldı"):
        n = 0
        for s in list(self.pos):
            p = self.pos[s]
            self._close(p, p["qty_open"], prices.get(s, p["entry"]), reason, now)
            n += 1
        return n

    def close_symbol(self, sym, price, now, reason="Elle kapatıldı"):
        p = self.pos.get(sym)
        if not p or (p.get("exch") and not self.demo_on):
            return False
        self._close(p, p["qty_open"], price, reason, now)
        return True

    def external_close(self, sym, price, now, reason):
        """Borsada (stop tetiklenmesi veya elle) kapanmış pozisyonu emir göndermeden defterden düşür."""
        p = self.pos.get(sym)
        if p:
            self._close(p, p["qty_open"], price, reason, now, send=False)

    def adopt(self, sym, side, qty, entry, price, atr, lev, now, saved=None):
        """Borsada açık ama defterde olmayan pozisyonu devral (askıda kalmasın)."""
        d = 1 if side == "LONG" else -1
        if saved and saved.get("side") == side:
            p = dict(saved)
            p.update({"hist": deque(maxlen=40), "qty_open": qty, "exch": True, "exch_ok": True, "restored": True})
            self.pos[sym] = p
            self.emit("adopt", {"symbol": sym, "side": side, "qty": qty, "restored": True, "sl": p["sl"]})
            return p
        r = max(self.cfg.sl_atr_mult * atr, entry * 0.005)
        sl = entry - d * r
        if (price - sl) * d < 0.5 * atr:
            sl = price - d * max(atr, price * 0.004)
            r = max(abs(entry - sl), price * 0.004)
        best = price if (price - entry) * d > 0 else entry
        worst = price if (price - entry) * d < 0 else entry
        p = {"symbol": sym, "side": side, "dir": d, "entry": entry, "qty": qty, "qty_open": qty, "sl": sl, "sl0": sl,
             "tps": [], "tp_hit": 0, "leverage": lev, "margin": qty * entry / lev, "opened": now, "fees": 0.0,
             "realized": 0.0, "score": 0, "reason": "Devralındı (borsada açık pozisyon)", "hist": deque(maxlen=40),
             "strat": "ADOPT", "r": r, "best": best, "atr": atr, "be_done": False, "partial_done": False,
             "trail_n": 0, "worst": worst, "sl_logged": sl, "free_logged": False, "exch": True, "exch_ok": True}
        self.pos[sym] = p
        self.emit("adopt", {"symbol": sym, "side": side, "qty": qty, "entry": entry, "sl": sl, "atr": atr, "restored": False})
        return p

    def dump(self):
        return {"start": self.start, "balance": self.balance, "peak": self.peak, "max_dd": self.max_dd, "day": self.day,
                "day_start": self.day_start, "consec": self.consec_losses, "cooldown": self.cooldown_until,
                "block": self.block_until, "closed": self.closed[-300:],
                "pos": {s: {k: v for k, v in p.items() if k != "hist"} for s, p in self.pos.items()}}

    def load(self, d):
        self.start, self.balance = d.get("start", self.start), d.get("balance", self.balance)
        self.peak, self.max_dd = d.get("peak", self.balance), d.get("max_dd", 0.0)
        self.day, self.day_start = d.get("day", self.day), d.get("day_start", self.balance)
        self.consec_losses, self.cooldown_until = d.get("consec", 0), d.get("cooldown", 0.0)
        self.block_until, self.closed = d.get("block", {}), d.get("closed", [])
        for s, p in d.get("pos", {}).items():
            p["hist"] = deque(maxlen=40)
            p["restored"] = True
            self.pos[s] = p

    def abort(self, sym):
        """Demo giriş emri reddedilirse sanal pozisyonu geri al."""
        p = self.pos.pop(sym, None)
        self.block_until.pop(sym, None)
        if p:
            self.balance += p["fees"]

    def reset(self):
        if self.pos:
            return False
        self.start = self.balance = self.peak = self.day_start = self.cfg.start_balance
        self.max_dd, self.closed, self.halted = 0.0, [], None
        self.consec_losses, self.cooldown_until = 0, 0.0
        return True

    # ---------- istatistik ----------
    def stats(self):
        pnls = [r["pnl"] for r in self.closed]
        wins = [x for x in pnls if x > 0]
        losses = [x for x in pnls if x <= 0]
        gl = -sum(losses)
        fin = [r for r in self.closed if r["final"]]
        sr = lambda a: round(100 * sum(1 for x in a if x > 0) / len(a), 1) if a else None
        L = [r["trade_total"] for r in fin if r["side"] == "LONG"]
        S_ = [r["trade_total"] for r in fin if r["side"] == "SHORT"]
        return {
            "start_balance": round(self.start, 2), "balance": round(self.balance, 2),
            "net_pnl": round(self.balance - self.start, 2),
            "net_pct": round((self.balance - self.start) / self.start * 100, 2) if self.start else None,
            "fills": len(pnls), "trades": len(fin), "win_rate": sr([r["trade_total"] for r in fin]),
            "profit_factor": round(sum(wins) / gl, 2) if gl > 0 else None,
            "avg_win": round(sum(wins) / len(wins), 3) if wins else None,
            "avg_loss": round(-gl / len(losses), 3) if losses else None,
            "max_drawdown_pct": round(self.max_dd * 100, 2),
            "long_trades": len(L), "short_trades": len(S_), "long_success": sr(L), "short_success": sr(S_),
            "halted": self.halted, "safe_mode": self.safe_mode, "paused": self.paused,
        }
