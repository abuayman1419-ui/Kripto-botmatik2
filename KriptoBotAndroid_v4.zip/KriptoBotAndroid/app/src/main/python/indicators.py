"""Saf pandas/numpy indikatörleri. DataFrame sütunları: t,o,h,l,c,v,qv,tb (tb = taker buy base hacmi)."""
import numpy as np
import pandas as pd


def ema(s, n):
    return s.ewm(span=n, adjust=False).mean()


def rsi(c, n=14):
    d = c.diff()
    up = d.clip(lower=0).ewm(alpha=1 / n, adjust=False).mean()
    dn = (-d.clip(upper=0)).ewm(alpha=1 / n, adjust=False).mean()
    return 100 - 100 / (1 + up / dn.replace(0, np.nan))


def macd(c, f=12, s=26, sig=9):
    m = ema(c, f) - ema(c, s)
    sg = ema(m, sig)
    return m, sg, m - sg


def atr(df, n=14):
    pc = df.c.shift()
    tr = pd.concat([df.h - df.l, (df.h - pc).abs(), (df.l - pc).abs()], axis=1).max(axis=1)
    return tr.ewm(alpha=1 / n, adjust=False).mean()


def bollinger(c, n=20, k=2.0):
    m = c.rolling(n).mean()
    sd = c.rolling(n).std()
    return m + k * sd, m, m - k * sd


def vwap(df, n=48):
    tp = (df.h + df.l + df.c) / 3
    return (tp * df.v).rolling(n).sum() / df.v.rolling(n).sum()


def adx(df, n=14):
    up, dn = df.h.diff(), -df.l.diff()
    pdm = pd.Series(np.where((up > dn) & (up > 0), up, 0.0), index=df.index)
    mdm = pd.Series(np.where((dn > up) & (dn > 0), dn, 0.0), index=df.index)
    a = atr(df, n)
    pdi = 100 * pdm.ewm(alpha=1 / n, adjust=False).mean() / a
    mdi = 100 * mdm.ewm(alpha=1 / n, adjust=False).mean() / a
    dx = 100 * (pdi - mdi).abs() / (pdi + mdi).replace(0, np.nan)
    return dx.ewm(alpha=1 / n, adjust=False).mean(), pdi, mdi


def obv(df):
    return (np.sign(df.c.diff()).fillna(0) * df.v).cumsum()


def mfi(df, n=14):
    tp = (df.h + df.l + df.c) / 3
    mf = tp * df.v
    pos = mf.where(tp > tp.shift(), 0.0).rolling(n).sum()
    neg = mf.where(tp < tp.shift(), 0.0).rolling(n).sum()
    return 100 - 100 / (1 + pos / neg.replace(0, np.nan))


def stoch_rsi(c, n=14):
    r = rsi(c, n)
    lo, hi = r.rolling(n).min(), r.rolling(n).max()
    return (r - lo) / (hi - lo).replace(0, np.nan)


def supertrend(df, n=10, mult=3.0):
    """+1 yükseliş, -1 düşüş."""
    a = atr(df, n)
    hl2 = (df.h + df.l) / 2
    ub, lb = (hl2 + mult * a).to_numpy(copy=True), (hl2 - mult * a).to_numpy(copy=True)
    c = df.c.to_numpy()
    d = np.ones(len(df))
    for i in range(1, len(df)):
        if c[i] > ub[i - 1]:
            d[i] = 1
        elif c[i] < lb[i - 1]:
            d[i] = -1
        else:
            d[i] = d[i - 1]
            if d[i] == 1:
                lb[i] = max(lb[i], lb[i - 1])
            else:
                ub[i] = min(ub[i], ub[i - 1])
    return pd.Series(d, index=df.index)


def last(s, default=0.0):
    try:
        v = float(s.iloc[-1])
        return default if np.isnan(v) else v
    except Exception:
        return default
