"""CRYPTO AI TERMINAL - PAPER modu. Çalıştır:  python backend/main.py   ->  http://localhost:8000"""
import asyncio
import json
import logging
import os
import sys
import time
import traceback
from contextlib import asynccontextmanager

sys.path.insert(0, os.path.dirname(__file__))
import uvicorn
from fastapi import FastAPI, Request
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, RedirectResponse, Response

from auth import LOGIN_HTML, MIN_LEN, Auth, is_loopback
from binance_api import Futures, Stream, rows_to_df
import insight
import logs
import reversal
import settings
from config import CFG
from demo_exec import Demo
from logsum import export_zip, summarize
from shadow import Shadow
from news import NewsFeed
from paper_engine import PaperEngine
from scoring import analyze, btc_bias, regime
from util import clean

HOST = os.environ.get("TERMINAL_HOST", "127.0.0.1")
PORT = int(os.environ.get("PORT") or os.environ.get("TERMINAL_PORT") or 8000)
PIN = os.environ.get("TERMINAL_PIN", "")      # Android uygulaması her kurulumda rastgele PIN verir
auth = Auth(PIN, os.path.join(CFG.log_dir, "session.key"))
api = Futures()
engine = PaperEngine(CFG)
feed = NewsFeed()
demo = Demo()
settings.load(CFG)
engine.start = engine.balance = engine.peak = engine.day_start = CFG.start_balance
flt_default = {"step": 0.001, "minq": 0.001, "notional": 5}
logs.setup(CFG.log_dir)
log = logging.getLogger("bot")
jl = logs.jlog
sh = Shadow(jl)
engine.on_event = lambda n, d: jl("trade_events", dict(d, ev=n))
feed.on_alarm = lambda it: jl("alarms", {"id": it["id"], "title": it["title"], "level": it["level"],
                                         "coins": it["coins"], "sources": it["sources"]})
jl("config_changes", {"src": "startup", "cfg": settings.get_values(CFG)})
_dec = {}
DATA_DIR = "data"
STATE_PATH = os.path.join(DATA_DIR, "engine_state.json")
KEYS_PATH = os.path.join(DATA_DIR, "demo_keys.json")


def gate():
    """Yeni işlem açma kapısı: Binance demo bağlı + senkron olmalı (ayar: require_exchange)."""
    if not CFG.require_exchange:
        return ""
    if CFG.mode != "DEMO" or not demo.connected:
        return "Binance (demo) bağlantısı yok: önce bağlanın"
    if not demo.synced():
        return "Binance senkronu eski/başarısız"
    return ""


engine.gate = gate


def persist():
    try:
        os.makedirs(DATA_DIR, exist_ok=True)
        d = engine.dump()
        d["mode"] = CFG.mode
        tmp = STATE_PATH + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(d, fh, default=str)
        os.replace(tmp, STATE_PATH)
    except Exception:
        log_err("durum kaydı")


def restore():
    try:
        with open(STATE_PATH, encoding="utf-8") as fh:
            d = json.load(fh)
        engine.load(d)
        log.info("Önceki durum yüklendi: %s pozisyon, bakiye %.2f", len(engine.pos), engine.balance)
        jl("config_changes", {"src": "restore", "pos": list(engine.pos), "balance": engine.balance})
    except FileNotFoundError:
        pass
    except Exception:
        log_err("durum yükleme")
S = {"status": "Başlıyor...", "opps": [], "regime": "-", "scan_ts": 0, "universe": 0,
     "errors": [], "scan_ms": 0, "scan_note": "", "rest_fallback": 0}
stream = None
qv24 = {}
sem = asyncio.Semaphore(8)
BG = set()          # görev referansları (çöp toplayıcı görevleri öldürmesin)
LAST_GOOD = {}


def spawn(coro):
    t = asyncio.create_task(coro)
    BG.add(t)
    t.add_done_callback(BG.discard)
    return t


def log_err(where):
    log.error("%s: %s", where, traceback.format_exc())
    line = traceback.format_exc(limit=3).strip().splitlines()[-1]
    S["errors"] = (S["errors"] + [f"{time.strftime('%H:%M:%S')} {where}: {line}"])[-10:]


async def safe(coro):
    async with sem:
        try:
            return await coro
        except Exception:
            return None


async def reseed(syms):
    async def one(s):
        r = await safe(api.klines(s, "1m", CFG.warmup_candles))
        if r:
            stream.seed(s, r)
    await asyncio.gather(*(one(s) for s in syms))


def decide(sym, strat, reason, ctx=None):
    """Reddedilen girişleri (aynı sebep 10 dk'da bir) logla."""
    k, now = (sym, strat, reason), time.time()
    if now - _dec.get(k, 0) < 600:
        return
    _dec[k] = now
    jl("decisions", dict({"sym": sym, "strat": strat, "reason": reason}, **(ctx or {})))


def sig_rec(r):
    rv = r.get("rev")
    d = {"sym": r["symbol"], "side": r["side"], "signal": r["signal"], "score": r["score"], "long": r["long"],
         "short": r["short"], "price": r["price"], "sl": r["sl"], "tps": r["tps"], "biases": r["biases"],
         "patterns": r["patterns"], "failed": [k for k, v in r["filters"].items() if not v], "vr": r["vol_ratio"],
         "tb": r["taker_buy"], "oi": r["oi_change_pct"], "fund": r["funding"], "rsi5": r["rsi5"],
         "regime": S.get("regime"), "btc": S.get("btc_bias")}
    if rv:
        d["rev"] = {"type": rv["type"], "score": rv["score"], "stage": rv["stage"], "entry_ok": rv["entry_ok"],
                    "blocked": rv["blocked"], "cats": rv["cats"]}
    return d


def prefilter(alive):
    """TÜM izlenen sembolleri 1m verisiyle hızlıca tarar (DataFrame'siz); derin analiz için en hareketli likit adayları seçer."""
    sc, fresh, liq_fresh, fresh_syms = [], 0, 0, []
    liquid = sum(1 for s in alive if qv24.get(s, 0) >= CFG.min_qv24)
    for s in alive:
        r = stream.rows.get(s, [])
        if len(r) < 36 or stream.age(s) > 90:
            continue
        fresh += 1
        fresh_syms.append(s)
        if qv24.get(s, 0) < CFG.min_qv24:
            continue
        liq_fresh += 1
        c = [float(x[4]) for x in r[-36:-1]]
        v = [float(x[5]) for x in r[-36:-1]]
        r5 = abs(c[-1] / c[-6] - 1) * 100
        vr = (sum(v[-3:]) / 3) / max(sum(v[:-3]) / len(v[:-3]), 1e-12)
        sc.append((r5 + 0.5 * vr, s))
    cands = [s for _, s in sorted(sc, reverse=True)[:CFG.deep_n]]
    return cands, {"fresh": fresh, "liquid": liquid, "liquid_fresh": liq_fresh}, sorted(fresh_syms)


async def deep(sym, funding, b_bias):
    k5, k15, k1, dp, oi = await asyncio.gather(
        safe(api.klines(sym, "5m", 120)), safe(api.klines(sym, "15m", 120)), safe(api.klines(sym, "1h", 168)),
        safe(api.depth(sym, 20)), safe(api.oi_change(sym)))
    if not k5 or not k15:
        return None
    try:
        f = {"5m": rows_to_df(k5[:-1]), "15m": rows_to_df(k15[:-1])}   # açık mum atılır
        if k1:
            f["1h"] = rows_to_df(k1[:-1])
        r = analyze(sym, f, dp, oi, funding.get(sym), b_bias, qv24.get(sym, 0), CFG,
                    news_bias=feed.bias_for(sym), news_flag=feed.critical_for(sym))
        r["news"] = [{"title": i.get("title_tr") or i["title"], "level": i["level"]} for i in feed.for_symbol(sym, 6)[:3]]
        r.update(insight.build(r, f, CFG))
        rv = reversal.detect(sym, f, r, b_bias, CFG)
        r["atr15"] = rv["atr15"]
        if rv["type"]:
            r["rev"] = rv
        return r
    except Exception:
        log_err(f"analiz {sym}")
        return None


def rev_prescreen(tk, alive, n=12):
    """24s değişim + 24s aralık konumuna göre dip/tepe adayları (7g doğrulaması derin analizde yapılır). Yalnızca likit coinler."""
    dip, top = [], []
    for s in alive:
        t = tk.get(s)
        if not t or t["hi"] <= t["lo"] or stream.age(s) > 90 or qv24.get(s, 0) < CFG.min_qv24:
            continue
        pos = (stream.price.get(s, t["last"]) - t["lo"]) / (t["hi"] - t["lo"])
        if t["chg"] <= -2.5 and pos <= 0.5:
            dip.append((abs(t["chg"]) * (1 - pos), s))
        if t["chg"] >= 2.5 and pos >= 0.5:
            top.append((abs(t["chg"]) * pos, s))
    return [s for _, s in sorted(dip, reverse=True)[:n]] + [s for _, s in sorted(top, reverse=True)[:n]]


async def scan_once():
    t0 = time.time()
    alive = S.get("alive") or set(stream.symbols)
    # WebSocket gecikmişse (likit semboller için) REST ile yenile
    stale = [s for s in stream.symbols if s in alive and qv24.get(s, 0) >= CFG.min_qv24 and stream.age(s) > 45]
    S["rest_fallback"] = len(stale)
    if stale:
        await reseed(stale)
    b5, b15 = await asyncio.gather(safe(api.klines("BTCUSDT", "5m", 120)), safe(api.klines("BTCUSDT", "15m", 120)))
    if not b5 or not b15:
        S["scan_note"] = "BTC verisi alınamadı (API/ağ). Önceki sonuçlar gösteriliyor."
        log.warning("BTC verisi alınamadı")
        return
    d5, d15 = rows_to_df(b5[:-1]), rows_to_df(b15[:-1])
    bb = btc_bias(d5, d15)
    S["regime"], S["btc_bias"] = regime(bb, d5), round(float(bb), 2)
    funding = await safe(api.funding_all()) or {}
    tk = await safe(api.tickers()) or {}
    for s_, t_ in tk.items():                       # 24s hacim bilgisini her taramada tazele
        if s_ in qv24:
            qv24[s_] = t_["qv"]
    cands0, cov, fresh_syms = prefilter(alive)
    pri = list(dict.fromkeys(cands0 + rev_prescreen(tk, alive) + list(engine.pos)))
    # Geri kalan TÜM semboller dönüşümlü partilerle derin analize girer (API limitini aşmamak için tarama başına rotate_n)
    pool = [x for x in fresh_syms if x not in set(pri)]
    if pool and CFG.rotate_n > 0:
        i = S.get("rot_i", 0) % len(pool)
        batch = (pool + pool)[i:i + min(CFG.rotate_n, len(pool))]
        S["rot_i"] = (i + CFG.rotate_n) % len(pool)
    else:
        batch = []
    cands = list(dict.fromkeys(pri + batch))
    S["cover"] = dict(cov, perp_total=api.total, streams=len(stream.symbols), deep=len(cands), min_qv=CFG.min_qv24,
                      ts=time.time())
    if not cands:
        S["scan_note"] = "Taze veri yok; önceki sonuçlar gösteriliyor."
        log.warning("Taze veri yok (fresh=%s)", cov["fresh"])
        return
    res = [r for r in await asyncio.gather(*(deep(s, funding, bb) for s in cands)) if r]
    if not res:
        S["scan_note"] = "Analiz üretilemedi (API limiti/hata olabilir). Önceki sonuçlar gösteriliyor."
        log.warning("Analiz üretilemedi, aday=%s", len(cands))
        return
    res.sort(key=lambda r: -r["score"])
    now = time.time()
    cache = S.setdefault("cache", {})                # dönüşümlü analiz sonuçları: sembol -> (zaman, sonuç)
    for r in res:
        cache[r["symbol"]] = (now, r)
    for k in [k for k, (t_, _) in cache.items() if now - t_ > CFG.cache_ttl]:
        del cache[k]
    allr = sorted((r for _, r in cache.values()), key=lambda r: -r["score"])
    S["opps"], S["scan_ts"], S["scan_ms"], S["scan_note"] = allr, time.time(), int((time.time() - t0) * 1000), ""
    S["cover"]["analyzed"] = len(allr)
    sides = {"LONG": {"n": 0, "sig": 0, "blocked": {}}, "SHORT": {"n": 0, "sig": 0, "blocked": {}}}
    for r in allr:
        sd = sides[r["side"]]
        sd["n"] += 1
        if r["signal"] != "WAIT":
            sd["sig"] += 1
            continue
        for k in [k for k, v in r["filters"].items() if not v] or ["Puan eşiği altı"]:
            sd["blocked"][k] = sd["blocked"].get(k, 0) + 1
    S["sides"] = sides
    by = {r["symbol"]: r for r in res}
    for r in res:                               # dönüş listesindeki coinler yalnızca REV stratejisine ayrılır
        if r.get("rev") and r["rev"]["score"] >= 50:
            r["reserved"] = True
    for s, p in engine.pos.items():                      # trailing için güncel ATR
        if p["strat"] == "REV" and s in by and by[s].get("atr15"):
            p["atr"] = by[s]["atr15"]
    # 1) Dönüş (dip/tepe) stratejisi
    for r in res:
        rv = r.get("rev")
        if not rv:
            continue
        traded = False
        if not rv["entry_ok"]:
            rv["result"] = "Bekliyor: " + (", ".join(rv["blocked"]) if rv["blocked"] else "onay/puan yetersiz")
            if rv["score"] >= 60:
                decide(r["symbol"], "REV", rv["result"], {"score": rv["score"], "stage": rv["stage"]})
        elif not CFG.rev_enabled:
            rv["result"] = "Dönüş stratejisi kapalı"
        else:
            px = stream.price.get(r["symbol"])
            if px is None or stream.age(r["symbol"]) > CFG.stale_seconds:
                rv["result"] = "Fiyat verisi bayat"
            else:
                opp = {"symbol": r["symbol"], "side": rv["side"], "price": r["price"], "atr": rv["atr15"], "sl": rv["sl"],
                       "score": rv["score"], "note": rv["note"], "strat": "REV", "ctx": sig_rec(r)}
                traded, why = engine.open(opp, px, now)
                rv["result"] = "Açıldı" if traded else why
                if not traded:
                    decide(r["symbol"], "REV", why, {"score": rv["score"]})
        if rv["entry_ok"] or (rv["stage"] == "ONAYLI" and rv["score"] >= CFG.rev_threshold - 10):
            sh.add("REV", {"symbol": r["symbol"], "side": rv["side"], "price": r["price"], "sl": rv["sl"], "score": rv["score"]},
                   now, traded, 2.0, 360, sig_rec(r))
    # 2) Standart strateji
    for r in res:
        if r["signal"] == "WAIT":
            continue
        rv = r.get("rev")
        traded = False
        if r.get("reserved"):
            r["paper_result"] = "Dönüş listesinde: standart işlem kapalı"
            continue
        else:
            px = stream.price.get(r["symbol"])
            if px is not None and stream.age(r["symbol"]) <= CFG.stale_seconds:
                traded, why = engine.open(dict(r, ctx=sig_rec(r)), px, now)
                r["paper_result"] = "Açıldı" if traded else why
                if not traded:
                    decide(r["symbol"], "STD", why, {"score": r["score"], "side": r["side"]})
        sh.add("STD", r, now, traded, CFG.tp_r[0], 60, sig_rec(r))
    # loglar
    n = 0
    for r in res:
        if n < 25 and (r["signal"] != "WAIT" or r["score"] >= 70 or (r.get("rev") and r["rev"]["score"] >= 55)):
            jl("signals", sig_rec(r))
            n += 1
    jl("scan_stats", {"ms": S["scan_ms"], "fresh": cov["fresh"], "liquid": cov["liquid"], "deep": len(cands),
                      "perp_total": api.total, "streams": len(stream.symbols), "regime": S["regime"], "btc": S["btc_bias"],
                      "sides": sides, "rest_fallback": S["rest_fallback"], "ws_missing": not stream.healthy(),
                      "ws": [stream.connected, stream.expected], "open_pos": len(engine.pos),
                      "active": engine.active_count(), "balance": round(engine.balance, 2), "errors": len(S["errors"])})


async def scan_loop():
    while True:
        try:
            await scan_once()
        except Exception:
            log_err("tarama")
        await asyncio.sleep(CFG.scan_seconds)


async def mark_loop():
    while True:
        try:
            engine.safe_mode = not stream.healthy()
            for s in list(engine.pos):                      # açık pozisyon fiyatı bayatsa REST'ten al
                if stream.age(s) > CFG.stale_seconds:
                    p = await safe(api.price(s))
                    if p:
                        stream.price[s], stream.ts[s] = p, time.time()
            prices = {s: p for s, p in stream.price.items() if s in engine.pos and stream.age(s) <= CFG.stale_seconds * 3}
            engine.mark(prices, time.time())
            sh.update(stream.price, time.time())
            if int(time.time()) % 10 == 0:
                persist()
            if not engine.eq_hist or time.time() - engine.eq_hist[-1][0] >= 15:
                engine.eq_hist.append((time.time(), round(engine.equity(stream.price), 2)))
            if engine.safe_mode:
                S["status"] = f"WS {stream.connected}/{stream.expected}: yeni PAPER işlem kapalı, veri REST ile yenileniyor"
            else:
                S["status"] = "Canlı veri akışı OK (PAPER)"
        except Exception:
            log_err("takip")
        await asyncio.sleep(2)


async def exec_one(o):
    sym = o["sym"]
    flt = api.filters.get(sym, flt_default)
    price = stream.price.get(sym, 1)
    if o["kind"] == "open":
        r = await demo.place(sym, o["side"], o["qty"], False, flt, CFG.leverage, price)
        pp = engine.pos.get(sym)
        if not pp:
            return
        ap = float(r.get("avgPrice") or 0)
        if ap > 0 and abs(ap - pp["entry"]) / pp["entry"] < 0.01:     # gerçek dolum fiyatına hizala (R mesafeleri korunur)
            dl = ap - pp["entry"]
            pp["entry"] += dl
            pp["sl"] += dl
            pp["sl0"] += dl
            pp["tps"] = [t + dl for t in pp["tps"]]
            pp["best"] = pp["worst"] = ap
        pp["exch_ok"] = True
        res = await demo.set_stop(sym, o["side"], pp["sl"], flt.get("tick"))
        if res != "OK":
            raise RuntimeError("Borsa stop emri yerleştirilemedi (" + res + ")")
        return
    qty = o["qty"]
    if o.get("final") and sym in demo.pos_snapshot:
        qty = demo.pos_snapshot[sym]["qty"]                        # toz bırakmamak için borsadaki miktarı kapat
    for attempt in range(3):
        try:
            await demo.place(sym, o["side"], qty, True, flt, CFG.leverage, price)
            break
        except Exception as e:
            m = str(e).lower()
            if "-2022" in m or "reduceonly" in m or "miktar borsa limitlerinin altında" in m:
                break                                              # zaten kapalı / toz
            if attempt == 2:
                raise
            await asyncio.sleep(1.5)
    if o.get("final"):
        try:
            await demo.cancel_stops(sym)
        except Exception:
            pass


async def executor_loop():
    """Motorun ürettiği emirleri DEMO hesabına gönderir (yalnızca mod=DEMO ve bağlıysa)."""
    while True:
        try:
            engine.demo_on = CFG.mode == "DEMO" and demo.connected
            while engine.queue:
                o = engine.queue.pop(0)
                try:
                    await exec_one(o)
                except Exception as e:
                    demo.note(f"HATA {o['kind']} {o['sym']}: {str(e)[:140]}")
                    log.error("emir hatası %s %s: %s", o["kind"], o["sym"], e)
                    if o["kind"] == "open":
                        try:       # korumasız pozisyon bırakma: açıldıysa hemen kapat
                            await demo.place(o["sym"], o["side"], o["qty"], True, api.filters.get(o["sym"], flt_default),
                                             CFG.leverage, stream.price.get(o["sym"], 1))
                        except Exception:
                            pass
                        try:
                            await demo.cancel_stops(o["sym"])
                        except Exception:
                            pass
                        engine.abort(o["sym"])
            if demo.connected and int(time.time()) % 30 == 0:
                await demo.refresh_balance()
        except Exception:
            log_err("emir")
        await asyncio.sleep(1)


def _atr_for(sym, entry):
    for r in S.get("opps", []):
        if r["symbol"] == sym and r.get("atr15"):
            return r["atr15"]
    return entry * 0.012


async def sync_once():
    """Binance demo ile senkron: dışarıda kapananları düşür, askıdaki pozisyonları devral, borsa SL'lerini koru."""
    now = time.time()
    pos = await demo.positions()
    demo.pos_snapshot, demo.last_sync, demo.sync_fail = pos, now, 0
    for s, p in list(engine.pos.items()):
        if not p.get("exch"):
            continue
        if not p.get("exch_ok") and now - p["opened"] < 60:
            continue
        x = pos.get(s)
        if x is None or x["side"] != p["side"]:
            px = stream.price.get(s, p["entry"])
            st = demo.stops.get(s)
            if st and (px - st["price"]) * p["dir"] <= 0:
                reason, exit_px = "Borsada stop tetiklendi", st["price"]
            else:
                reason, exit_px = "Borsada elle kapatıldı", px
            engine.external_close(s, exit_px, now, reason)
            demo.note(f"{s} borsada kapanmış ({reason}); defterden düşürüldü")
            jl("trade_events", {"ev": "exchange_closed", "symbol": s, "reason": reason, "px": exit_px})
            try:
                await demo.cancel_stops(s)
            except Exception:
                pass
        else:
            if abs(x["qty"] - p["qty_open"]) / max(p["qty_open"], 1e-12) > 0.02:
                jl("trade_events", {"ev": "qty_sync", "symbol": s, "engine": p["qty_open"], "exchange": x["qty"]})
                p["qty_open"] = x["qty"]
    for s, x in pos.items():
        if s in engine.pos:
            continue
        if now - engine.closing.get(s, 0) < 90 or any(q["sym"] == s for q in engine.queue):
            continue                                   # kapatma emri yolda
        price = stream.price.get(s, x["mark"])
        saved = None
        engine.adopt(s, x["side"], x["qty"], x["entry"], price, _atr_for(s, x["entry"]), CFG.leverage, now, saved)
        demo.note(f"{s} {x['side']} borsada açıktı, devralındı (SL atanacak)")
        log.warning("Askıdaki pozisyon devralındı: %s %s", s, x["side"])
    # borsa SL'lerini koru / güncelle
    for s, p in list(engine.pos.items()):
        if not p.get("exch") or not p.get("exch_ok") or s not in pos:
            continue
        flt = api.filters.get(s, flt_default)
        st = demo.stops.get(s)
        if st and now - st.get("chk", 0) > 30:
            await demo.check_stop(s)
            st = demo.stops.get(s)
        tick = flt.get("tick") or 0
        need = st is None or ((p["sl"] - st["price"]) * p["dir"] > max(tick, 0.001 * p["entry"]) and now - st["ts"] >= 8)
        if need:
            res = await demo.set_stop(s, p["side"], p["sl"], tick)
            if res == "TRIGGERED":                      # fiyat zaten stopun ötesinde: hemen kapat
                engine.close_symbol(s, stream.price.get(s, p["entry"]), now, "Stop (borsa)")
                jl("trade_events", {"ev": "stop_immediate", "symbol": s, "sl": p["sl"]})


async def sync_loop():
    last_try = 0.0
    while True:
        try:
            if demo.connected:
                try:
                    await sync_once()
                except Exception as e:
                    demo.sync_fail += 1
                    demo.err = str(e)[:140]
                    log.warning("senkron hatası (%s): %s", demo.sync_fail, e)
                    if demo.sync_fail >= 3:
                        demo.connected = False
                        demo.note("Bağlantı koptu; yeniden denenecek")
            elif demo.key and time.time() - last_try > 15:       # kopan bağlantıyı otomatik yeniden kur
                last_try = time.time()
                try:
                    await demo.connect(demo.key, demo.secret, demo.env)
                    demo.sync_fail = 0
                    log.info("Demo bağlantısı yeniden kuruldu")
                except Exception as e:
                    demo.err = str(e)[:140]
        except Exception:
            log_err("sync")
        await asyncio.sleep(5)


async def autoconnect():
    c = Demo.load_creds(KEYS_PATH)
    if not c:
        return
    try:
        logs.register_secret(c["key"], c["secret"])
        await demo.connect(c["key"], c["secret"], c.get("env", "demo"))
        CFG.mode = "DEMO"
        log.info("Kayıtlı demo anahtarıyla otomatik bağlanıldı")
    except Exception as e:
        demo.err = str(e)[:140]
        log.warning("Otomatik bağlanma başarısız: %s", e)


async def universe_loop():
    """30 dakikada bir yeni listelenen sembolleri ekler, delist olanları dışlar."""
    while True:
        await asyncio.sleep(1800)
        try:
            syms, q = await api.universe(CFG)
            for k, v in q.items():
                qv24.setdefault(k, v)
            S["alive"] = set(syms)
            added = stream.add(syms)
            if added:
                await reseed(added)
                log.info("Yeni semboller eklendi: %s", added)
                jl("universe", {"added": added, "total": api.total})
            feed.universe = {x[:-4] for x in stream.symbols}
        except Exception:
            log_err("evren yenile")


async def boot():
    global stream, qv24
    try:
        while True:
            try:
                syms, qv24 = await api.universe(CFG)
                break
            except Exception:
                log_err("evren")
                S["status"] = "Binance'e bağlanılamadı, tekrar deneniyor"
                await asyncio.sleep(10)
        feed.universe = {s[:-4] for s in syms}
        S["universe"] = len(syms)
        S["alive"] = set(syms)
        log.info("Evren: %s sembol izlenecek (Binance TRADING USDT perpetual toplamı: %s)", len(syms), api.total)
        jl("universe", {"streams": len(syms), "perp_total": api.total, "min_qv24": CFG.min_qv24, "max_symbols": CFG.max_symbols})
        stream = Stream(syms, CFG)
        S["status"] = f"{len(syms)} sembol için warmup..."
        await reseed(syms)
        stream.start()
        await asyncio.sleep(3)
        spawn(mark_loop())
        spawn(executor_loop())
        spawn(scan_loop())
        spawn(universe_loop())
        spawn(sync_loop())
        spawn(autoconnect())
    except Exception:
        log_err("boot")


@asynccontextmanager
async def lifespan(app):
    restore()
    spawn(feed.run())
    spawn(boot())
    yield
    persist()
    await api.close()


app = FastAPI(lifespan=lifespan)
HERE = os.environ.get("TERMINAL_WEB_DIR") or os.path.dirname(__file__)
PUBLIC = {"/login"}


@app.middleware("http")
async def gate(request: Request, call_next):
    if not auth.enabled:
        return await call_next(request)
    p = request.url.path
    if p in PUBLIC or auth.valid(request.cookies.get("session")):
        return await call_next(request)
    if p.startswith("/api/"):
        return JSONResponse({"ok": False, "msg": "giriş gerekli"}, status_code=401)
    return RedirectResponse("/login", status_code=303)


@app.get("/login")
def login_page():
    if not auth.enabled:
        return RedirectResponse("/", status_code=303)
    return HTMLResponse(LOGIN_HTML, headers={"Cache-Control": "no-store"})


@app.post("/login")
async def login(req: Request):
    if not _guard(req):
        return JSONResponse({"ok": False, "msg": "yetkisiz"}, status_code=403)
    try:
        pin = str((await req.json()).get("pin", ""))
    except Exception:
        pin = ""
    token, err = auth.login(pin)
    if err:
        return JSONResponse({"ok": False, "msg": err}, status_code=429 if auth.locked() else 401)
    r = JSONResponse({"ok": True})
    r.set_cookie("session", token, max_age=30 * 86400, httponly=True, samesite="lax")
    return r


@app.post("/logout")
async def logout(req: Request):
    if not _guard(req):
        return JSONResponse({"ok": False, "msg": "yetkisiz"}, status_code=403)
    r = JSONResponse({"ok": True})
    r.delete_cookie("session")
    return r


@app.get("/")
def index():
    return FileResponse(os.path.join(HERE, "dashboard.html"), headers={"Cache-Control": "no-cache"})


def by_coin(prices):
    d = {}
    for r in engine.closed:
        c = d.setdefault(r["symbol"], {"symbol": r["symbol"], "trades": 0, "wins": 0, "realized": 0.0, "upnl": 0.0, "open": False})
        c["realized"] += r["pnl"]
        if r["final"]:
            c["trades"] += 1
            c["wins"] += 1 if (r.get("trade_total") or 0) > 0 else 0
    for s, p in engine.pos.items():
        c = d.setdefault(s, {"symbol": s, "trades": 0, "wins": 0, "realized": 0.0, "upnl": 0.0, "open": False})
        c["open"] = True
        c["upnl"] += (prices.get(s, p["entry"]) - p["entry"]) * p["qty_open"] * p["dir"]
    out = list(d.values())
    for c in out:
        c["realized"], c["upnl"] = round(c["realized"], 3), round(c["upnl"], 3)
        c["total"] = round(c["realized"] + c["upnl"], 3)
    return sorted(out, key=lambda c: -c["total"])


def log_info():
    out = {}
    try:
        for n in os.listdir(CFG.log_dir):
            out[n] = os.path.getsize(os.path.join(CFG.log_dir, n))
    except Exception:
        pass
    return out


def build_state():
    prices = stream.price if stream else {}
    now = time.time()
    allo = S["opps"]
    main_l = [o for o in allo if not o.get("reserved")][:CFG.show_n]
    ids = {id(o) for o in main_l}
    pinned = [dict(o, pinned=True) for o in allo if o["symbol"] in engine.pos and id(o) not in ids]
    opps = allo
    shown = pinned + main_l
    pos = [{"symbol": p["symbol"], "side": p["side"], "entry": p["entry"], "price": prices.get(s, p["entry"]),
            "qty_open": p["qty_open"], "sl": p["sl"], "tps": p["tps"], "tp_hit": p["tp_hit"],
            "margin": round(p["margin"], 2), "leverage": p["leverage"], "age_s": int(now - p["opened"]),
            "strat": p["strat"], "best": p["best"], "trail_n": p["trail_n"], "be": p["be_done"], "sl0": p["sl0"],
            "rmult": round((prices.get(s, p["entry"]) - p["entry"]) * p["dir"] / p["r"], 2), "free": engine.is_free(p),
            "upnl": round((prices.get(s, p["entry"]) - p["entry"]) * p["qty_open"] * p["dir"], 3),
            "exch": bool(p.get("exch")), "exch_ok": bool(p.get("exch_ok")), "ex_stop": (demo.stops.get(s) or {}).get("price"),
            "restored": bool(p.get("restored"))}
           for s, p in engine.pos.items()]
    flow = [o for o in opps if abs(o["biases"]["flow"]) >= 0.4 or abs(o["oi_change_pct"] or 0) >= 1]
    return {
        "status": S["status"], "mode": CFG.mode, "regime": S["regime"], "btc_bias": S.get("btc_bias"),
        "universe": S["universe"], "scan_age": int(now - S["scan_ts"]) if S["scan_ts"] else None,
        "scan_ms": S["scan_ms"], "scan_note": S["scan_note"], "errors": S["errors"],
        "long_candidates": sum(1 for o in main_l if o["signal"] == "BUY"),
        "short_candidates": sum(1 for o in main_l if o["signal"] == "SELL"),
        "opps": shown, "money_flow": flow[:10],
        "rev": sorted([o for o in opps if o.get("rev")], key=lambda o: -o["rev"]["score"])[:20],
        "sq_list": sorted([o for o in opps if o.get("sq") and (o["squeeze"] or o["sq"]["ratio"] < 0.8)], key=lambda o: o["sq"]["ratio"])[:8],
        "sides": S.get("sides"), "today_pnl": round(sum(r["pnl"] for r in engine.closed if r["time"].startswith(engine._today())), 3),
        "open_pnl": round(sum(p["upnl"] for p in pos), 3),
        "positions": pos, "closed": engine.closed[-30:][::-1],
        "stats": engine.stats(), "equity": round(engine.equity(prices), 2),
        "news": feed.listing(80), "news_status": feed.status, "paused": engine.paused, "max_pos": CFG.max_positions, "active_n": engine.active_count(), "total_n": len(engine.pos),
        "cover": S.get("cover"), "logs": log_info(),
        "by_coin": by_coin(prices), "eq_hist": [[int(t), v] for t, v in list(engine.eq_hist)[-240:]],
        "btc_spark": [float(r[4]) for r in (stream.rows.get("BTCUSDT", [])[-60:] if stream else [])],
        "btc_price": prices.get("BTCUSDT"),
        "demo": {"connected": demo.connected, "env": demo.env, "balance": demo.balance, "avail": demo.avail,
                 "synced": demo.synced(), "sync_age": int(now - demo.last_sync) if demo.last_sync else None,
                 "pos_n": len(demo.pos_snapshot), "stops_n": len(demo.stops), "err": demo.err[:140],
                 "has_keys": demo.key is not None},
        "exchange": [{"symbol": k, "side": x["side"], "qty": x["qty"], "entry": x["entry"], "mark": x["mark"],
                      "upnl": x["upnl"], "stop": (demo.stops.get(k) or {}).get("price"), "managed": k in engine.pos}
                     for k, x in demo.pos_snapshot.items()],
        "gate": gate(), "require_exchange": CFG.require_exchange,
        "blocks": [{"symbol": k, "min": int((v - now) / 60) + 1} for k, v in engine.block_until.items() if v > now],
        "ws": {"connected": stream.connected if stream else 0, "expected": stream.expected if stream else 0,
               "msgs": stream.msgs if stream else 0, "last_err": stream.last_err if stream else "",
               "rest_fallback": S["rest_fallback"]}}


@app.get("/api/state")
def state():
    global LAST_GOOD
    try:
        LAST_GOOD = clean(build_state())
        return JSONResponse(LAST_GOOD)
    except Exception:
        log_err("state")
        return JSONResponse(dict(LAST_GOOD, scan_note="Durum üretilemedi, son iyi veri gösteriliyor",
                                 errors=S["errors"]))


def _guard(req):
    return req.headers.get("x-requested-with") == "terminal"


@app.get("/api/candles")
async def candles(symbol: str, tf: str = "5m"):
    if not stream or symbol not in stream.rows or tf not in ("1m", "5m", "15m", "1h"):
        return JSONResponse({"error": "geçersiz"}, status_code=400)
    rows = await safe(api.klines(symbol, tf, 100))
    if not rows:
        return JSONResponse({"error": "veri yok"}, status_code=502)
    df = rows_to_df(rows)
    from indicators import bollinger, ema
    bu, bm, bl = bollinger(df.c)
    return JSONResponse(clean({"symbol": symbol, "tf": tf, "t": df.t.tolist(), "o": df.o.tolist(), "h": df.h.tolist(),
                               "l": df.l.tolist(), "c": df.c.tolist(), "ema20": ema(df.c, 20).tolist(),
                               "bbu": bu.tolist(), "bbl": bl.tolist()}))


@app.get("/api/settings")
def get_settings():
    return JSONResponse(clean({"schema": settings.schema(), "values": settings.get_values(CFG), "mode": CFG.mode,
                               "paused": engine.paused, "has_pos": len(engine.pos),
                               "demo": {"connected": demo.connected, "env": demo.env, "balance": demo.balance,
                                        "avail": demo.avail, "hedge": demo.hedge, "err": demo.err, "log": list(demo.log),
                                        "sync_age": int(time.time() - demo.last_sync) if demo.last_sync else None,
                                        "pos_n": len(demo.pos_snapshot), "stops_n": len(demo.stops)}}))


@app.post("/api/settings")
async def post_settings(req: Request):
    if not _guard(req):
        return JSONResponse({"ok": False, "errors": ["yetkisiz"]}, status_code=403)
    errs = settings.apply(CFG, (await req.json()).get("values", {}))
    jl("config_changes", {"src": "panel", "errors": errs, "cfg": settings.get_values(CFG)})
    msg = ""
    if not errs:
        settings.save(CFG)
        if abs(CFG.start_balance - engine.start) > 1e-9:
            msg = "Başlangıç bakiyesi güncellendi" if engine.set_start(CFG.start_balance) else "Açık pozisyon varken başlangıç bakiyesi değişmez"
    return JSONResponse({"ok": not errs, "errors": errs, "msg": msg})


@app.post("/api/control")
async def control(req: Request):
    if not _guard(req):
        return JSONResponse({"ok": False, "msg": "yetkisiz"}, status_code=403)
    a = (await req.json()).get("action")
    jl("config_changes", {"src": "control", "action": a})
    if a == "pause":
        engine.paused = True
    elif a == "resume":
        engine.paused = False
    elif a == "close_all":
        engine.paused = True
        n = engine.close_all(stream.price if stream else {}, time.time())
        return JSONResponse({"ok": True, "msg": f"{n} pozisyon kapatıldı, yeni işlemler durduruldu"})
    elif a == "reset":
        if not engine.reset():
            return JSONResponse({"ok": False, "msg": "Açık pozisyon varken sıfırlanamaz"})
    elif a == "sync_balance":
        if engine.pos or not demo.connected or demo.avail is None:
            return JSONResponse({"ok": False, "msg": "Demo bağlı olmalı ve açık pozisyon olmamalı"})
        CFG.start_balance = round(float(demo.avail), 2)
        engine.set_start(CFG.start_balance)
        settings.save(CFG)
    else:
        return JSONResponse({"ok": False, "msg": "bilinmeyen eylem"})
    return JSONResponse({"ok": True, "msg": "Tamam", "paused": engine.paused})


@app.post("/api/mode")
async def set_mode(req: Request):
    if not _guard(req):
        return JSONResponse({"ok": False, "msg": "yetkisiz"}, status_code=403)
    m = (await req.json()).get("mode")
    if m not in ("PAPER", "DEMO"):
        return JSONResponse({"ok": False, "msg": "geçersiz mod"})
    if m == "DEMO" and not demo.connected:
        return JSONResponse({"ok": False, "msg": "Önce demo hesabını bağlayın"})
    CFG.mode = m
    msg = ""
    if m == "DEMO" and demo.avail is not None and not engine.pos:
        CFG.start_balance = round(float(demo.avail), 2)
        engine.set_start(CFG.start_balance)
        settings.save(CFG)
        msg = f"Başlangıç bakiyesi demo hesaba göre {CFG.start_balance} USDT yapıldı"
    return JSONResponse({"ok": True, "mode": m, "msg": msg})


@app.post("/api/demo/connect")
async def demo_connect(req: Request):
    if not _guard(req):
        return JSONResponse({"ok": False, "msg": "yetkisiz"}, status_code=403)
    b = await req.json()
    logs.register_secret(b.get("key", "").strip(), b.get("secret", "").strip())
    try:
        await demo.connect(b.get("key", ""), b.get("secret", ""), b.get("env", "demo"))
        CFG.mode = "DEMO"
        if b.get("remember"):
            demo.save_creds(KEYS_PATH)
        jl("config_changes", {"src": "demo_connect", "env": demo.env, "remember": bool(b.get("remember"))})
        try:
            await sync_once()
        except Exception as e:
            demo.err = str(e)[:140]
        if not engine.pos and demo.avail is not None:
            CFG.start_balance = round(float(demo.avail), 2)
            engine.set_start(CFG.start_balance)
            settings.save(CFG)
        return JSONResponse({"ok": True, "balance": demo.balance, "adopted": len(engine.pos)})
    except Exception as e:
        demo.forget()
        demo.err = str(e)[:200]
        return JSONResponse({"ok": False, "msg": demo.err})


@app.post("/api/demo/disconnect")
async def demo_disconnect(req: Request):
    if not _guard(req):
        return JSONResponse({"ok": False, "msg": "yetkisiz"}, status_code=403)
    demo.forget()
    Demo.delete_creds(KEYS_PATH)
    CFG.mode = "PAPER"
    return JSONResponse({"ok": True})


@app.post("/api/close")
async def api_close(req: Request):
    if not _guard(req):
        return JSONResponse({"ok": False, "msg": "yetkisiz"}, status_code=403)
    sym = (await req.json()).get("symbol")
    p = engine.pos.get(sym)
    if not p:
        return JSONResponse({"ok": False, "msg": "Bu coinde açık pozisyon yok"})
    if not engine.close_symbol(sym, stream.price.get(sym, p["entry"]), time.time()):
        return JSONResponse({"ok": False, "msg": "Borsa bağlantısı yok: bu pozisyon borsadan elle kapatılmalı (borsadaki SL korumada)"})
    jl("trade_events", {"ev": "manual_close", "symbol": sym})
    return JSONResponse({"ok": True, "msg": f"{sym} kapatma emri verildi; {CFG.manual_close_block_min} dk yeniden açılmaz"})


@app.post("/api/sync")
async def api_sync(req: Request):
    if not _guard(req):
        return JSONResponse({"ok": False, "msg": "yetkisiz"}, status_code=403)
    if not demo.connected:
        return JSONResponse({"ok": False, "msg": "Demo bağlı değil"})
    try:
        await sync_once()
        return JSONResponse({"ok": True, "msg": f"Senkron tamam: borsada {len(demo.pos_snapshot)} pozisyon, defterde {len(engine.pos)}"})
    except Exception as e:
        return JSONResponse({"ok": False, "msg": str(e)[:160]})


@app.get("/api/logs/export")
def logs_export():
    return Response(export_zip(CFG.log_dir), media_type="application/zip",
                    headers={"Content-Disposition": f"attachment; filename=terminal_logs_{time.strftime('%Y%m%d_%H%M')}.zip"})


@app.get("/api/logs/summary")
def logs_summary():
    return JSONResponse({"text": summarize(CFG.log_dir)})


if __name__ == "__main__":
    if not is_loopback(HOST) and not auth.enabled:
        sys.exit("HATA: Ağa açık modda şifre (TERMINAL_PIN) zorunlu.")
    if auth.enabled and len(PIN) < MIN_LEN:
        sys.exit(f"HATA: TERMINAL_PIN en az {MIN_LEN} karakter olmalı.")
    uvicorn.run(app, host=HOST, port=PORT, log_level="warning")
