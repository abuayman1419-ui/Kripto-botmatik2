"""Tüm ayarlar burada. LIVE_TRADING bilinçli olarak yoktur: bu sürümde gerçek emir kodu bulunmaz."""
from dataclasses import dataclass, field


@dataclass
class Config:
    mode: str = "PAPER"
    # --- Evren ---
    min_qv24: float = 20_000_000      # 24s USDT hacmi alt sınırı (likidite filtresi)
    max_symbols: int = 0              # 0 = Binance'teki TÜM USDT perpetual sembolleri izle
    warmup_candles: int = 100
    stream_chunk: int = 100           # bağlantı başına stream sayısı
    # --- Tarama ---
    scan_seconds: int = 60
    deep_n: int = 20                  # her taramada ÖNCELİKLİ derin analize alınacak en hareketli likit aday sayısı
    rotate_n: int = 100               # geri kalan tüm semboller: tarama başına dönüşümlü derin analiz sayısı (0 = kapalı)
    cache_ttl: int = 420              # dönüşümlü analiz sonucu bu kadar sn geçerli (sonra listeden düşer)
    show_n: int = 600                 # Fırsat Merkezi'nde gösterilecek en fazla coin
    stale_seconds: int = 20           # bundan eski veriyle işlem açılmaz
    # --- Puanlama (toplam 100) ---
    weights: dict = field(default_factory=lambda: {
        "technical": 25, "flow": 20, "trend": 15, "orderbook": 10,
        "news": 10, "btc": 10, "oi_funding": 10})
    entry_threshold: float = 80
    opposite_max: float = 50
    max_spread_pct: float = 0.10
    max_chase_atr: float = 2.5
    min_sl_pct: float = 0.30
    max_sl_pct: float = 5.0
    sl_atr_mult: float = 1.5
    # --- Paper trading ---
    start_balance: float = 200.0
    leverage: int = 8
    max_positions: int = 2            # aktif (riskli) pozisyon sınırı; risksiz pozisyonlar sayılmaz
    max_total_positions: int = 10     # risksiz dahil mutlak üst sınır
    margin_pct: float = 0.45
    risk_pct: float = 0.02
    taker_fee: float = 0.0005
    tp_split: tuple = (0.5, 0.25, 0.25)
    tp_r: tuple = (1.0, 2.0, 3.0)
    max_hold_minutes: int = 180
    daily_loss_pct: float = 0.10
    max_consec_losses: int = 3
    cooldown_minutes: int = 30
    panic_move_pct: float = 1.5
    max_slippage_atr: float = 0.5
    # --- Dip/Tepe dönüş stratejisi (trailing stop) ---
    rev_enabled: int = 1
    rev_threshold: float = 70
    rev_trail_atr: float = 2.0        # trailing mesafesi (ATR15 katı)
    rev_be_r: float = 1.0             # bu kadar R kârda stop başa baş noktasına çekilir
    rev_partial_r: float = 0.0        # 0 = kısmi kâr kapalı
    rev_partial_pct: float = 0.25
    rev_max_hold_hours: int = 24
    require_exchange: int = 1         # 1 = Binance demo bağlı ve senkron değilse yeni işlem açma
    manual_close_block_min: int = 180 # elle kapatılan coin için yeniden giriş yasağı (dk)
    reentry_block_min: int = 20       # herhangi bir kapanıştan sonra aynı coine yeniden giriş yasağı (dk)
    btc_guard: float = 0.5            # 1.0 = BTC koruması kapalı
    log_dir: str = "logs"


CFG = Config()
