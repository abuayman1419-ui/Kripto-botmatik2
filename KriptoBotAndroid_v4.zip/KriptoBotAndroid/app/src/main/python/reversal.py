"""Dip / Tepe dönüş analizi. Dipte olup yükseliş trendine dönmesi beklenen coinler (DIP -> LONG) ve
tepede olup düşüşe dönmesi beklenenler (TOP -> SHORT) için 100 üzerinden puan üretir.
Puan olasılık değildir; kontrol listesidir. Her madde ✔/✖ olarak arayüzde gösterilir."""
import numpy as np
from indicators import atr, ema, last, macd, rsi
from patterns import detect as pat_detect

CAPS = {"Konum": 25, "Momentum": 25, "Yapı": 20, "Akış": 15, "Formasyon": 5, "BTC": 10}


def _piv(a, w=3, mx=False):
    f = max if mx else min
    return [i for i in range(w, len(a) - w) if a[i] == f(a[i - w:i + w + 1])]


def _score(sgn, d15, d1, o, b_bias, sym, cfg):
    price = o["price"]
    h1, l1 = d1.h.to_numpy(), d1.l.to_numpy()
    hi7, lo7 = float(h1.max()), float(l1.min())
    rng = max(hi7 - lo7, 1e-12)
    rpos = (price - lo7) / rng if sgn > 0 else (hi7 - price) / rng       # 0 = uç noktada
    extent = (hi7 - price) / hi7 * 100 if sgn > 0 else (price - lo7) / lo7 * 100
    c, h, l = d15.c.to_numpy(), d15.h.to_numpy(), d15.l.to_numpy()
    chk = []

    def add(cat, ok, txt, pts):
        chk.append({"cat": cat, "ok": bool(ok), "t": txt, "p": pts if ok else 0})

    side_t = "alt" if sgn > 0 else "üst"
    pts = 25 if rpos <= .15 else 20 if rpos <= .25 else 12 if rpos <= .35 else 0
    if extent < 5:
        pts *= .5
    add("Konum", pts > 0, f"7 günlük aralığın {side_t} %{rpos * 100:.0f}'inde, {'zirveden' if sgn > 0 else 'dipten'} %{extent:.1f} {'düşmüş' if sgn > 0 else 'yükselmiş'}", pts)

    r = rsi(d15.c)
    rec = r.iloc[-16:]
    r_now, r_3 = float(r.iloc[-1]), float(r.iloc[-3])
    if sgn > 0:
        add("Momentum", rec.min() < 32, f"RSI son 4 saatte {rec.min():.0f}'e indi (aşırı satım)", 8)
        add("Momentum", r_now > rec.min() + 6 and r_now > r_3, f"RSI dipten dönüyor ({rec.min():.0f} → {r_now:.0f})", 6)
    else:
        add("Momentum", rec.max() > 68, f"RSI son 4 saatte {rec.max():.0f}'e çıktı (aşırı alım)", 8)
        add("Momentum", r_now < rec.max() - 6 and r_now < r_3, f"RSI tepeden dönüyor ({rec.max():.0f} → {r_now:.0f})", 6)
    m = macd(d15.c)[2].to_numpy()
    add("Momentum", sgn * (m[-1] - m[-2]) > 0 and sgn * (m[-2] - m[-3]) > 0, f"MACD histogramı {'yukarı' if sgn > 0 else 'aşağı'} dönüyor", 6)
    ext = (l if sgn > 0 else h)[-60:]
    pv = _piv(ext, 3, mx=sgn < 0)
    rs = r.to_numpy()[-60:]
    div = False
    if len(pv) >= 2:
        i1, i2 = pv[-2], pv[-1]
        div = (ext[i2] < ext[i1] * .999 and rs[i2] > rs[i1] + 2) if sgn > 0 else (ext[i2] > ext[i1] * 1.001 and rs[i2] < rs[i1] - 2)
    add("Momentum", div, f"{'Pozitif' if sgn > 0 else 'Negatif'} RSI uyumsuzluğu (divergence)", 10)

    hl = len(pv) >= 2 and ((ext[pv[-1]] > ext[pv[-2]]) if sgn > 0 else (ext[pv[-1]] < ext[pv[-2]]))
    add("Yapı", hl, "Daha yüksek dip oluştu" if sgn > 0 else "Daha düşük tepe oluştu", 8)
    oth = (h if sgn > 0 else l)[-60:]
    opv = _piv(oth, 3, mx=sgn > 0)
    lvl = oth[opv[-1]] if opv else None
    bos = lvl is not None and ((c[-1] > lvl) if sgn > 0 else (c[-1] < lvl))
    add("Yapı", bos, f"Yapı kırılımı: son {'tepe' if sgn > 0 else 'dip'} ({lvl:.6g}) {'üstünde' if sgn > 0 else 'altında'} kapanış" if lvl else "Yapı kırılımı için pivot yok", 8)
    e20 = float(ema(d15.c, 20).iloc[-1])
    above = c[-1] > e20 if sgn > 0 else c[-1] < e20
    add("Yapı", above, f"Fiyat 15m EMA20'nin {'üstünde' if sgn > 0 else 'altında'}", 4)

    v = d15.v.to_numpy()
    add("Akış", v[-20:].max() > 2.5 * v[-60:-20].mean() and rpos < .4,
        "Uçta hacim patlaması (" + ("satış tükenişi / capitulation" if sgn > 0 else "alım tükenişi / blow-off") + ")", 6)
    tb = o["taker_buy"]
    add("Akış", tb > .55 if sgn > 0 else tb < .45, f"Taker {'alış' if sgn > 0 else 'satış'} baskısı (alış oranı %{tb * 100:.0f})", 5)
    oi = o["oi_change_pct"]
    add("Akış", oi is not None and oi > .3 and ((price > c[-4]) if sgn > 0 else (price < c[-4])), "Open Interest artarken fiyat dönüş yönünde", 2)
    fu = o["funding"]
    add("Akış", fu is not None and ((fu < -.0003) if sgn > 0 else (fu > .0005)), "Funding karşı tarafın kalabalık olduğunu gösteriyor", 2)

    pats = pat_detect(d15)
    bs = sum(p["bias"] for p in pats)
    add("Formasyon", sgn * bs > .3, "Formasyon: " + ", ".join(p["name"] for p in pats if p["bias"] * sgn > 0), 5)

    x = 0 if sym == "BTCUSDT" else sgn * b_bias
    add("BTC", x >= -.3, "BTC eğilimi dönüşü engellemiyor" if x >= -.3 else "BTC dönüşe ters yönde", 10 if x >= .3 else 6)

    cats = {k: min(CAPS[k], sum(c_["p"] for c_ in chk if c_["cat"] == k)) for k in CAPS}
    return {"sgn": sgn, "score": sum(cats.values()), "cats": cats, "checks": chk, "rpos": rpos, "extent": extent,
            "hi7": hi7, "lo7": lo7, "hl": hl, "bos": bos, "above": above, "mom": cats["Momentum"], "btc_x": x}


def detect(sym, f, o, b_bias, cfg):
    d15, d1 = f["15m"], f.get("1h")
    a15 = last(atr(d15))
    out = {"type": None, "atr15": a15}
    if d1 is None or len(d1) < 60 or len(d15) < 70 or a15 <= 0:
        return out
    best = max((_score(s, d15, d1, o, b_bias, sym, cfg) for s in (1, -1)), key=lambda r: r["score"])
    if best["score"] < 45 or best["extent"] < 4:
        return out
    sgn, price = best["sgn"], o["price"]
    l, h = d15.l.to_numpy(), d15.h.to_numpy()
    swing = float(l[-16:].min()) if sgn > 0 else float(h[-16:].max())
    sl = swing - sgn * 0.25 * a15
    sl_pct = abs(price - sl) / price * 100
    chase = abs(price - swing) / a15
    confirmed = best["hl"] and (best["bos"] or best["above"]) and best["mom"] >= 10
    flt = {"Spread uygun": o["spread_pct"] is None or o["spread_pct"] <= cfg.max_spread_pct,
           "Likidite yeterli": o["qv24"] >= cfg.min_qv24,
           "Giriş kaçmamış": chase <= 6,
           "Stop mesafesi makul (%0.5–6)": 0.5 <= sl_pct <= 6,
           "Kritik haber yok": o["filters"].get("Kritik haber yok", True),
           "BTC güçlü ters değil": best["btc_x"] >= -.6}
    blocked = [k for k, v in flt.items() if not v]
    side = "LONG" if sgn > 0 else "SHORT"
    entry_ok = bool(confirmed and best["score"] >= cfg.rev_threshold and not blocked)
    ks = (.382, .5, .618, .786)
    rng = best["hi7"] - best["lo7"]
    tg = [best["lo7"] + k * rng for k in ks] if sgn > 0 else [best["hi7"] - k * rng for k in ks]
    targets = [{"price": t, "pct": (t - price) / price * 100} for t in tg if (t > price if sgn > 0 else t < price)]
    ok_t = [c["t"] for c in best["checks"] if c["ok"]][:4]
    stage = "ONAYLI" if confirmed else "ERKEN (izle)"
    note = (f"{'DİP' if sgn > 0 else 'TEPE'} dönüşü adayı [{stage}], puan {best['score']:.0f}/100. " + "; ".join(ok_t) + ". "
            f"Plan: {side}, SL {sl:.6g} (%{sl_pct:.2f}); kâr {cfg.rev_be_r:g}R'ye ulaşınca stop girişe çekilir, sonrasında "
            f"{cfg.rev_trail_atr:g}×ATR ile {'yukarı' if sgn > 0 else 'aşağı'} taşınır (sabit TP yok). ")
    if targets:
        note += "Olası bölgeler (7g aralığın Fibonacci seviyeleri): " + ", ".join(f"{t['price']:.6g} ({t['pct']:+.1f}%)" for t in targets[:3]) + ". "
    note += "Bunlar senaryodur, garanti değildir."
    out.update({"type": "DIP" if sgn > 0 else "TOP", "side": side, "score": round(best["score"], 1), "stage": stage,
                "cats": best["cats"], "checks": best["checks"], "rpos_pct": round(best["rpos"] * 100, 1),
                "extent_pct": round(best["extent"], 2), "hi7": best["hi7"], "lo7": best["lo7"], "sl": sl,
                "sl_pct": round(sl_pct, 2), "entry_ok": entry_ok, "blocked": blocked, "filters": flt,
                "targets": targets, "note": note, "result": ""})
    return out
