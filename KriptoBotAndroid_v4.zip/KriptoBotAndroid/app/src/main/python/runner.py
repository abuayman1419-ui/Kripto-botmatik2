"""Android uygulamasından çağrılır: botu (FastAPI) telefonun içinde 127.0.0.1:8000'de başlatır."""
import os
import pkgutil


def start(files_dir, pin):
    os.chdir(files_dir)                       # logs/ ve ayarlar uygulamanın özel klasörüne yazılır
    os.environ["TERMINAL_PIN"] = pin          # başka uygulamaların localhost'tan erişimini engeller
    os.environ["TERMINAL_HOST"] = "127.0.0.1"
    web = os.path.join(files_dir, "web")
    os.makedirs(web, exist_ok=True)
    with open(os.path.join(web, "dashboard.html"), "wb") as fh:
        fh.write(pkgutil.get_data("web", "dashboard.html"))
    os.environ["TERMINAL_WEB_DIR"] = web
    import main
    import uvicorn
    uvicorn.run(main.app, host="127.0.0.1", port=8000, log_level="warning")
