"""Log altyapısı: bot.log (dönen metin log) + jsonl olay dosyaları. Anahtar/secret/imza otomatik maskelenir."""
import json
import logging
import logging.handlers
import os
import re
import time

from util import clean

DIR = "logs"
_secrets = set()
_cnt = {}


def register_secret(*xs):
    for x in xs:
        if x and len(x) >= 8:
            _secrets.add(x)


def scrub(t):
    t = re.sub(r"signature=[0-9a-fA-F]+", "signature=***", str(t))
    t = re.sub(r"\b[0-9a-fA-F]{64}\b", "***", t)
    for x in _secrets:
        t = t.replace(x, "***")
    return t


class _Scrub(logging.Filter):
    def filter(self, rec):
        rec.msg, rec.args = scrub(rec.getMessage()), ()
        return True


def setup(directory="logs"):
    global DIR
    DIR = directory
    os.makedirs(DIR, exist_ok=True)
    lg = logging.getLogger("bot")
    lg.setLevel(logging.INFO)
    if lg.handlers:
        return lg
    fmt = logging.Formatter("%(asctime)s %(levelname)s %(name)s %(message)s")
    h = logging.handlers.RotatingFileHandler(os.path.join(DIR, "bot.log"), maxBytes=5_000_000, backupCount=5, encoding="utf-8")
    c = logging.StreamHandler()
    c.setLevel(logging.WARNING)
    for x in (h, c):
        x.setFormatter(fmt)
        x.addFilter(_Scrub())
        lg.addHandler(x)
    return lg


def jlog(name, obj, max_bytes=25_000_000):
    """logs/<name>.jsonl dosyasına tek satır JSON ekler (boyut sınırı aşılınca .1'e döner)."""
    try:
        path = os.path.join(DIR, name + ".jsonl")
        line = scrub(json.dumps({"ts": round(time.time(), 1), "t": time.strftime("%Y-%m-%d %H:%M:%S"), **clean(obj)},
                                ensure_ascii=False, default=str))
        _cnt[name] = _cnt.get(name, 0) + 1
        if _cnt[name] % 200 == 0 and os.path.exists(path) and os.path.getsize(path) > max_bytes:
            os.replace(path, path + ".1")
        with open(path, "a", encoding="utf-8") as fh:
            fh.write(line + "\n")
    except Exception:
        pass
