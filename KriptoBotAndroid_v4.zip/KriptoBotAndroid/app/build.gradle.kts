plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.chaquo.python")
}

android {
    namespace = "com.kriptobot.terminal"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.kriptobot.terminal"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        ndk { abiFilters += listOf("arm64-v8a") }   // güncel telefonlar; APK küçük kalır
    }
    signingConfigs {
        getByName("debug") {   // sabit anahtar: yeni APK eskisinin üstüne güncelleme olarak yüklenir
            storeFile = rootProject.file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

chaquopy {
    defaultConfig {
        version = "3.11"
        // Derleme bilgisayarındaki Python (3.8+). Windows'ta "py" başlatıcısı, diğerlerinde python3.
        if (System.getProperty("os.name").lowercase().contains("win")) buildPython("py", "-3") else buildPython("python3")
        pip {
            options("--only-binary=:all:")
            install("numpy")
            install("pandas")
            install("aiohttp")
            install("websockets")
            install("pydantic<2")
            install("fastapi==0.99.1")
            install("uvicorn")
        }
    }
}
